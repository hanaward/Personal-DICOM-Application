import sys
import os
import json
from PyQt5.QtWidgets import (QApplication, QMainWindow, QVBoxLayout, QHBoxLayout, 
                             QWidget, QPushButton, QTabWidget, QListWidget, QLabel,
                             QGroupBox, QSlider, QComboBox, QSplitter, QTextEdit, 
                             QSpinBox, QCheckBox, QRadioButton, QButtonGroup,
                             QMenuBar, QAction, QToolBar, QStatusBar, QFileDialog,
                             QMessageBox, QProgressBar, QDoubleSpinBox, QLineEdit,
                             QSizePolicy, QGridLayout, QDialog, QInputDialog, QDockWidget, QColorDialog,
                             QProgressDialog)
from PyQt5.QtCore import Qt, QSize, QTimer, pyqtSignal, QDateTime
from PyQt5.QtGui import QFont, QIcon
from vtk.qt.QVTKRenderWindowInteractor import QVTKRenderWindowInteractor
import vtk
from pathlib import Path
from vtk.util.colors import cornflower

class DetachableSliceViewer(QDockWidget):
    """Detachable dock widget for slice viewing that syncs with main controls"""
    
    sliceChanged = pyqtSignal(int)  # Signal when slice changes
    orientationChanged = pyqtSignal(str)  # Signal when orientation changes
    
    def __init__(self, parent=None):
        super().__init__("Slice Viewer", parent)
        self.setAllowedAreas(Qt.LeftDockWidgetArea | Qt.RightDockWidgetArea | Qt.BottomDockWidgetArea)
        self.setFeatures(QDockWidget.DockWidgetMovable | QDockWidget.DockWidgetFloatable | QDockWidget.DockWidgetClosable)
        
        self.vtk_app = None
        self.current_orientation = 'axial'
        self.current_slice = 0
        self.max_slices = 0
        
        self.setup_ui()
        
    def setup_ui(self):
        central_widget = QWidget()
        self.setWidget(central_widget)
        
        layout = QVBoxLayout()
        central_widget.setLayout(layout)
        
        # Toolbar
        toolbar = QHBoxLayout()
        
        # Orientation selector
        toolbar.addWidget(QLabel("Orientation:"))
        self.orientation_combo = QComboBox()
        self.orientation_combo.addItems(["Axial", "Coronal", "Sagittal"])
        self.orientation_combo.currentTextChanged.connect(self.on_orientation_changed)
        toolbar.addWidget(self.orientation_combo)
        
        toolbar.addStretch()
        
        # Sync checkbox
        self.sync_checkbox = QCheckBox("Sync with 3D View")
        self.sync_checkbox.setChecked(True)
        self.sync_checkbox.setFont(QFont("Arial", 9))
        toolbar.addWidget(self.sync_checkbox)
        
        layout.addLayout(toolbar)
        
        # VTK widget for slice display
        self.vtk_widget = QVTKRenderWindowInteractor()
        self.vtk_widget.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.vtk_widget.setMinimumSize(400, 400)
        layout.addWidget(self.vtk_widget)
        
        # Setup VTK renderer for slice
        self.renderer = vtk.vtkRenderer()
        self.renderer.SetBackground(0.1, 0.1, 0.1)  # Dark background for better contrast
        self.window = self.vtk_widget.GetRenderWindow()
        self.window.AddRenderer(self.renderer)
        self.interactor = self.vtk_widget.GetRenderWindow().GetInteractor()
        
        # Current slice info
        info_layout = QHBoxLayout()
        self.slice_info_label = QLabel("No data loaded")
        self.slice_info_label.setFont(QFont("Arial", 9))
        self.slice_info_label.setStyleSheet("color: #90EE90; font-weight: bold;")
        info_layout.addWidget(self.slice_info_label)
        info_layout.addStretch()
        layout.addLayout(info_layout)
        
        # Slice controls
        slice_controls = QHBoxLayout()
        slice_controls.addWidget(QLabel("Slice:"))
        
        self.slice_slider = QSlider(Qt.Horizontal)
        self.slice_slider.valueChanged.connect(self.on_slice_changed)
        self.slice_slider.setMaximumHeight(20)
        slice_controls.addWidget(self.slice_slider)
        
        self.slice_label = QLabel("0/0")
        self.slice_label.setFont(QFont("Arial", 9))
        self.slice_label.setMinimumWidth(40)
        slice_controls.addWidget(self.slice_label)
        
        # Navigation buttons
        prev_btn = QPushButton("◀")
        prev_btn.setMaximumWidth(30)
        prev_btn.setToolTip("Previous slice")
        prev_btn.clicked.connect(self.previous_slice)
        slice_controls.addWidget(prev_btn)
        
        next_btn = QPushButton("▶")
        next_btn.setMaximumWidth(30)
        next_btn.setToolTip("Next slice")
        next_btn.clicked.connect(self.next_slice)
        slice_controls.addWidget(next_btn)
        
        layout.addLayout(slice_controls)
        
    def on_orientation_changed(self, orientation):
        self.current_orientation = orientation.lower()
        self.orientationChanged.emit(self.current_orientation)
        self.update_slice_view()
        
    def on_slice_changed(self, value):
        self.current_slice = value
        self.update_slice_label()
        self.sliceChanged.emit(value)
        self.update_slice_view()
        
    def previous_slice(self):
        if self.current_slice > 0:
            self.slice_slider.setValue(self.current_slice - 1)
            
    def next_slice(self):
        if self.current_slice < self.max_slices:
            self.slice_slider.setValue(self.current_slice + 1)
            
    def update_slice_label(self):
        self.slice_label.setText(f"{self.current_slice}/{self.max_slices}")
        
    def set_slice_data(self, vtk_app):
        """Set the VTK application data and initialize slice viewing"""
        self.vtk_app = vtk_app
        if vtk_app and vtk_app.imageData:
            self.update_slice_view()
            
    def update_slice_view(self):
        """Update the slice display with current transformations and color settings"""
        if not self.vtk_app or not self.vtk_app.imageData:
            return
            
        # Clear previous actors
        self.renderer.RemoveAllViewProps()
        
        # Apply transformations to the image data
        transformed_data = self.apply_transformations(self.vtk_app.imageData)
        
        # Create slice mapper
        slice_mapper = vtk.vtkImageSliceMapper()
        slice_mapper.SetInputData(transformed_data)
        
        # Set orientation
        if self.current_orientation == 'axial':
            slice_mapper.SetOrientationToZ()
            self.max_slices = self.vtk_app.dims[2] - 1
        elif self.current_orientation == 'coronal':
            slice_mapper.SetOrientationToY()
            self.max_slices = self.vtk_app.dims[1] - 1
        elif self.current_orientation == 'sagittal':
            slice_mapper.SetOrientationToX()
            self.max_slices = self.vtk_app.dims[0] - 1
            
        # Update slider range if needed
        if self.slice_slider.maximum() != self.max_slices:
            self.slice_slider.setRange(0, self.max_slices)
            if self.current_slice > self.max_slices:
                self.current_slice = self.max_slices // 2
            self.slice_slider.setValue(self.current_slice)
            
        slice_mapper.SetSliceNumber(self.current_slice)
        
        # Create image slice
        image_slice = vtk.vtkImageSlice()
        image_slice.SetMapper(slice_mapper)
        
        # Apply color mapping from main volume properties
        self.apply_color_mapping(image_slice)
        
        # Add to renderer
        self.renderer.AddViewProp(image_slice)
        
        # Update slice info
        self.update_slice_info()
        
        # Reset camera for optimal view
        self.renderer.ResetCamera()
        
        # Render
        self.window.Render()
        
    def apply_transformations(self, image_data):
        """Apply current transformations to the image data"""
        # For now, return the original data
        # In a full implementation, this would apply:
        # - Translation
        # - Rotation  
        # - Scaling
        # - Window/Level
        return image_data
        
    def apply_color_mapping(self, image_slice):
        """Apply color mapping from main volume properties"""
        if not self.vtk_app or not hasattr(self.vtk_app, 'volumeProperty'):
            # Create default grayscale lookup table
            lut = vtk.vtkLookupTable()
            lut.SetRange(0, 255)
            lut.SetValueRange(0.0, 1.0)
            lut.SetSaturationRange(0.0, 0.0)
            lut.SetRampToLinear()
            lut.Build()
            image_slice.GetProperty().SetLookupTable(lut)
            return
            
        # Use the same color transfer function as the volume
        if hasattr(self.vtk_app, 'color') and self.vtk_app.color:
            # Create a lookup table from the color transfer function
            lut = vtk.vtkLookupTable()
            lut.SetNumberOfColors(256)
            lut.Build()
            
            # Sample the color transfer function
            scalar_range = self.vtk_app.scalar_range
            for i in range(256):
                value = scalar_range[0] + (scalar_range[1] - scalar_range[0]) * i / 255.0
                rgb = [0, 0, 0]
                self.vtk_app.color.GetColor(value, rgb)
                lut.SetTableValue(i, rgb[0], rgb[1], rgb[2], 1.0)
                
            image_slice.GetProperty().SetLookupTable(lut)
            
    def update_slice_info(self):
        """Update slice information display"""
        if self.vtk_app and self.vtk_app.imageData:
            dims = self.vtk_app.dims
            spacing = self.vtk_app.spacing
            info_text = f"Slice {self.current_slice}/{self.max_slices} | Dims: {dims} | Spacing: {spacing[0]:.2f}, {spacing[1]:.2f}, {spacing[2]:.2f} mm"
            self.slice_info_label.setText(info_text)
            
    def set_slice(self, orientation, slice_number):
        """Set slice from external control"""
        if orientation != self.current_orientation:
            self.orientation_combo.setCurrentText(orientation.capitalize())
        else:
            self.slice_slider.setValue(slice_number)


class HelpDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Medical DICOM Viewer - Help")
        self.setGeometry(100, 100, 500, 400)

        layout = QVBoxLayout()
        help_text = QTextEdit()
        help_text.setReadOnly(True)
        help_text.setHtml("""
        <h2>Medical DICOM Viewer - Help</h2>
        <h3>Navigation Controls</h3>
        <ul>
        <li><b>Left-click + drag</b> Rotate view</li>
        <li><b>Right-click + drag</b> Zoom in/out</li>
        <li><b>Middle-click + drag</b> Pan the view</li>
        </ul>
        <h3>Slice Viewing</h3>
        <ul>
        <li><b>Slice Viewer Dock</b> Detachable panel for 2D slice viewing</li>
        <li><b>Sync with 3D View</b> Keep slice viewer synchronized with main controls</li>
        <li><b>Transformations</b> All color and transform settings apply to slices</li>
        <li>Drag the slice viewer to detach it as a separate window</li>
        </ul>
        <h3>About</h3>
        <p>Advanced DICOM Medical Visualizer with VTK and PyQt5</p>
        <p>-ABB-2025</p>
        """)
        layout.addWidget(help_text)
        close_btn = QPushButton("Close")
        close_btn.clicked.connect(self.close)
        layout.addWidget(close_btn)
        self.setLayout(layout)


class myVTK:
    def __init__(self):
        vtk.vtkOutputWindow.SetGlobalWarningDisplay(0)
        self.renderer = None
        self.window = None
        self.interactor = None
        self.imageData = None
        self.reader = None
        self.volumeMapper = None
        self.volumeProperty = None
        self.volume = None
        self.initial_camera_position = None
        
        self.slice_actors = {}
        self.current_slice_mode = None
        self.slice_number = {'axial': 0, 'coronal': 0, 'sagittal': 0}
        self.max_slices = {'axial': 0, 'coronal': 0, 'sagittal': 0}
        
        # Transformation properties
        self.transformation = vtk.vtkTransform()
        self.transformation_filter = vtk.vtkImageReslice()

    def create_simple_coordinate_system(self):
        assembly = vtk.vtkAssembly()

        # Create X-axis (Red)
        x_axis = vtk.vtkLineSource()
        x_axis.SetPoint1(0, 0, 0)
        x_axis.SetPoint2(50, 0, 0)
        x_mapper = vtk.vtkPolyDataMapper()
        x_mapper.SetInputConnection(x_axis.GetOutputPort())
        x_actor = vtk.vtkActor()
        x_actor.SetMapper(x_mapper)
        x_actor.GetProperty().SetColor(1, 0, 0)
        x_actor.GetProperty().SetLineWidth(3)
        assembly.AddPart(x_actor)

        # Create Y-axis (Green)
        y_axis = vtk.vtkLineSource()
        y_axis.SetPoint1(0, 0, 0)
        y_axis.SetPoint2(0, 50, 0)
        y_mapper = vtk.vtkPolyDataMapper()
        y_mapper.SetInputConnection(y_axis.GetOutputPort())
        y_actor = vtk.vtkActor()
        y_actor.SetMapper(y_mapper)
        y_actor.GetProperty().SetColor(0, 1, 0)
        y_actor.GetProperty().SetLineWidth(3)
        assembly.AddPart(y_actor)

        # Create Z-axis (Blue)
        z_axis = vtk.vtkLineSource()
        z_axis.SetPoint1(0, 0, 0)
        z_axis.SetPoint2(0, 0, 50)
        z_mapper = vtk.vtkPolyDataMapper()
        z_mapper.SetInputConnection(z_axis.GetOutputPort())
        z_actor = vtk.vtkActor()
        z_actor.SetMapper(z_mapper)
        z_actor.GetProperty().SetColor(0, 0, 1)
        z_actor.GetProperty().SetLineWidth(3)
        assembly.AddPart(z_actor)

        assembly.SetPosition(-80, -80, -80)
        return assembly

    def load_dicom_data(self, directory):
        try:
            print(f"Loading DICOM from: {directory}")
            
            if not os.path.exists(directory):
                print(f"Directory does not exist: {directory}")
                return False
            
            # Create DICOM reader
            self.reader = vtk.vtkDICOMImageReader()
            self.reader.SetDirectoryName(str(directory))
            self.reader.SetDataByteOrderToLittleEndian()
            self.reader.Update()
            
            self.imageData = self.reader.GetOutput()
            if self.imageData is None:
                print("Failed to read DICOM data")
                return False
                
            # Get image information
            dims = self.imageData.GetDimensions()
            spacing = self.imageData.GetSpacing()
            scalar_range = self.imageData.GetScalarRange()
            
            print(f"DICOM loaded - Dimensions: {dims}, Range: {scalar_range}")
            
            # Set slice information
            self.dims = dims
            self.spacing = spacing
            self.scalar_range = scalar_range
            
            # Set maximum slice numbers for each orientation
            self.max_slices = {
                'axial': dims[2] - 1,
                'coronal': dims[1] - 1,  
                'sagittal': dims[0] - 1
            }
            
            # Initialize slice number to middle slice
            self.slice_number = {
                'axial': dims[2] // 2,
                'coronal': dims[1] // 2,
                'sagittal': dims[0] // 2
            }
            
            self.setup_transformation_pipeline()
            
            # Create volume mapper
            self.volumeMapper = vtk.vtkSmartVolumeMapper()
            self.volumeMapper.SetInputConnection(self.transformation_filter.GetOutputPort())
            
            # Create volume property
            self.volumeProperty = vtk.vtkVolumeProperty()
            self.volumeProperty.ShadeOn()
            self.volumeProperty.SetInterpolationTypeToLinear()
            
            # Create transfer functions
            self.scalarOpacity = vtk.vtkPiecewiseFunction()
            self.color = vtk.vtkColorTransferFunction()
            
            min_val, max_val = scalar_range
            range_span = max_val - min_val
            
            # Create a simple opacity ramp based on data range
            self.scalarOpacity.AddPoint(min_val, 0.0)
            self.scalarOpacity.AddPoint(min_val + range_span * 0.3, 0.1)
            self.scalarOpacity.AddPoint(min_val + range_span * 0.5, 0.3)
            self.scalarOpacity.AddPoint(min_val + range_span * 0.7, 0.6)
            self.scalarOpacity.AddPoint(max_val, 1.0)
            
            # Create color mapping
            self.color.AddRGBPoint(min_val, 0.0, 0.0, 0.0)
            self.color.AddRGBPoint(min_val + range_span * 0.3, 0.8, 0.4, 0.2)
            self.color.AddRGBPoint(min_val + range_span * 0.5, 0.9, 0.7, 0.5)
            self.color.AddRGBPoint(min_val + range_span * 0.7, 0.9, 0.9, 0.8)
            self.color.AddRGBPoint(max_val, 1.0, 1.0, 1.0)
            
            self.volumeProperty.SetScalarOpacity(self.scalarOpacity)
            self.volumeProperty.SetColor(self.color)

            # Create the volume
            self.volume = vtk.vtkVolume()
            self.volume.SetMapper(self.volumeMapper)
            self.volume.SetProperty(self.volumeProperty)

            print("DICOM volume created successfully")
            return True
            
        except Exception as e:
            print(f"Error loading DICOM data: {str(e)}")
            import traceback
            traceback.print_exc()
            return False

    def setup_transformation_pipeline(self):
        """Setup pipeline for applying transformations"""
        self.transformation_filter.SetInputData(self.imageData)
        self.transformation_filter.SetResliceTransform(self.transformation)
        self.transformation_filter.SetInterpolationModeToLinear()
        self.transformation_filter.SetOutputDimensionality(3)
        self.transformation_filter.Update()

    def apply_translation(self, x, y, z):
        """Apply translation transformation"""
        self.transformation.Translate(x, y, z)
        self.transformation_filter.Update()
        
    def apply_rotation(self, x, y, z):
        """Apply rotation transformation"""
        self.transformation.RotateX(x)
        self.transformation.RotateY(y)
        self.transformation.RotateZ(z)
        self.transformation_filter.Update()
        
    def apply_scaling(self, scale):
        """Apply scaling transformation"""
        self.transformation.Scale(scale, scale, scale)
        self.transformation_filter.Update()

    def reset_transformations(self):
        """Reset all transformations"""
        self.transformation.Identity()
        self.transformation_filter.Update()

    def get_transformed_data(self):
        """Get the transformed image data for slice viewing"""
        return self.transformation_filter.GetOutput()

    def setup_rendering_pipeline(self, vtk_widget):
        self.renderer = vtk.vtkRenderer()
        self.renderer.SetBackground(cornflower)
        self.window = vtk_widget.GetRenderWindow()
        self.window.AddRenderer(self.renderer)
        self.interactor = vtk_widget.GetRenderWindow().GetInteractor()
        self.interactor.SetInteractorStyle(vtk.vtkInteractorStyleTrackballCamera())

    def create_slice_actor(self, orientation, slice_number):
        """Create a slice actor for the given orientation and slice number"""
        if self.imageData is None:
            return None
            
        # Create image slice mapper
        slice_mapper = vtk.vtkImageSliceMapper()
        slice_mapper.SetInputConnection(self.transformation_filter.GetOutputPort())
        
        # Set orientation
        if orientation == 'axial':
            slice_mapper.SetOrientationToZ()
            slice_mapper.SetSliceNumber(slice_number)
        elif orientation == 'coronal':
            slice_mapper.SetOrientationToY()
            slice_mapper.SetSliceNumber(slice_number)
        elif orientation == 'sagittal':
            slice_mapper.SetOrientationToX()
            slice_mapper.SetSliceNumber(slice_number)
        
        # Create image slice
        image_slice = vtk.vtkImageSlice()
        image_slice.SetMapper(slice_mapper)
        
        # Apply the same color mapping as volume
        if hasattr(self, 'color') and self.color:
            lut = vtk.vtkLookupTable()
            lut.SetNumberOfColors(256)
            lut.Build()
            
            scalar_range = self.scalar_range
            for i in range(256):
                value = scalar_range[0] + (scalar_range[1] - scalar_range[0]) * i / 255.0
                rgb = [0, 0, 0]
                self.color.GetColor(value, rgb)
                lut.SetTableValue(i, rgb[0], rgb[1], rgb[2], 1.0)
                
            image_slice.GetProperty().SetLookupTable(lut)
        
        return image_slice

    def show_slice(self, orientation, slice_number):
        """Show a specific slice in the given orientation"""
        if self.imageData is None:
            return False
            
        # Remove existing slice actors
        self.remove_slice_actors()
        
        # Create and add new slice actor
        slice_actor = self.create_slice_actor(orientation, slice_number)
        if slice_actor:
            self.renderer.AddViewProp(slice_actor)
            self.slice_actors[orientation] = slice_actor
            self.current_slice_mode = orientation
            self.slice_number[orientation] = slice_number
            
            # Set appropriate camera for slice view
            self.set_slice_camera(orientation)
            return True
        return False

    def remove_slice_actors(self):
        """Remove all slice actors from the renderer"""
        for orientation, actor in self.slice_actors.items():
            self.renderer.RemoveViewProp(actor)
        self.slice_actors.clear()

    def set_slice_camera(self, orientation):
        """Set camera for optimal slice viewing"""
        if self.imageData is None:
            return
            
        camera = self.renderer.GetActiveCamera()
        
        # Get transformed bounds
        transformed_data = self.get_transformed_data()
        bounds = transformed_data.GetBounds()
        
        # Set camera based on orientation
        if orientation == 'axial':
            # XY plane - looking from top
            camera.SetPosition(
                (bounds[0] + bounds[1]) / 2,
                (bounds[2] + bounds[3]) / 2,
                bounds[5] + max(bounds[1]-bounds[0], bounds[3]-bounds[2])
            )
            camera.SetFocalPoint(
                (bounds[0] + bounds[1]) / 2,
                (bounds[2] + bounds[3]) / 2,
                (bounds[4] + bounds[5]) / 2
            )
            camera.SetViewUp(0, 1, 0)
            camera.SetParallelProjection(True)
            camera.SetParallelScale(max(bounds[1]-bounds[0], bounds[3]-bounds[2]) / 2)
            
        elif orientation == 'coronal':
            # XZ plane - looking from front
            camera.SetPosition(
                (bounds[0] + bounds[1]) / 2,
                bounds[3] + max(bounds[1]-bounds[0], bounds[5]-bounds[4]),
                (bounds[4] + bounds[5]) / 2
            )
            camera.SetFocalPoint(
                (bounds[0] + bounds[1]) / 2,
                (bounds[2] + bounds[3]) / 2,
                (bounds[4] + bounds[5]) / 2
            )
            camera.SetViewUp(0, 0, 1)
            camera.SetParallelProjection(True)
            camera.SetParallelScale(max(bounds[1]-bounds[0], bounds[5]-bounds[4]) / 2)
            
        elif orientation == 'sagittal':
            # YZ plane - looking from left
            camera.SetPosition(
                bounds[1] + max(bounds[3]-bounds[2], bounds[5]-bounds[4]),
                (bounds[2] + bounds[3]) / 2,
                (bounds[4] + bounds[5]) / 2
            )
            camera.SetFocalPoint(
                (bounds[0] + bounds[1]) / 2,
                (bounds[2] + bounds[3]) / 2,
                (bounds[4] + bounds[5]) / 2
            )
            camera.SetViewUp(0, 0, 1)
            camera.SetParallelProjection(True)
            camera.SetParallelScale(max(bounds[3]-bounds[2], bounds[5]-bounds[4]) / 2)
        
        self.renderer.ResetCamera()
        self.window.Render()

    def create_scene(self, directory=None):
        try:
            if self.renderer:
                self.renderer.RemoveAllViewProps()
            
            # Add medical volume rendering if directory provided
            if directory:
                success = self.load_dicom_data(directory)
                if success and self.volume:
                    self.renderer.AddVolume(self.volume)
                    print("Volume successfully added to renderer")
                else:
                    # Add error text
                    text_actor = vtk.vtkTextActor()
                    text_actor.SetInput("DICOM Load Failed\nCheck console for details")
                    text_actor.GetTextProperty().SetColor(1, 0, 0)
                    text_actor.GetTextProperty().SetFontSize(20)
                    text_actor.SetPosition(10, 10)
                    self.renderer.AddActor2D(text_actor)
            else:
                # Add message for empty scene
                text_actor = vtk.vtkTextActor()
                text_actor.SetInput("No dataset loaded\nUse 'Load DICOM' to add a dataset")
                text_actor.GetTextProperty().SetColor(0.8, 0.8, 0.8)
                text_actor.GetTextProperty().SetFontSize(24)
                text_actor.GetTextProperty().SetJustificationToCentered()
                text_actor.SetPosition(300, 300)
                self.renderer.AddActor2D(text_actor)

            # Always add coordinate system
            axes = self.create_simple_coordinate_system()
            self.renderer.AddActor(axes)

            # Reset camera
            self.renderer.ResetCamera()
            if self.volume:
                self.renderer.ResetCameraClippingRange()
            
            # Store initial camera position
            self.initial_camera_position = self.get_camera_state()
            
        except Exception as e:
            print(f"Error in create_scene: {str(e)}")

    def get_camera_state(self):
        camera = self.renderer.GetActiveCamera()
        return {
            'position': camera.GetPosition(),
            'focal_point': camera.GetFocalPoint(),
            'view_up': camera.GetViewUp(),
            'view_angle': camera.GetViewAngle()
        }

    def set_camera_state(self, state):
        camera = self.renderer.GetActiveCamera()
        camera.SetPosition(state['position'])
        camera.SetFocalPoint(state['focal_point'])
        camera.SetViewUp(state['view_up'])
        camera.SetViewAngle(state['view_angle'])

    def render_all(self):
        self.window.Render()
        self.interactor.Initialize()

    def reset_view(self):
        if self.initial_camera_position:
            self.set_camera_state(self.initial_camera_position)
        else:
            self.renderer.ResetCamera()
        self.window.Render()

    def start(self, vtk_widget, directory=None):
        self.setup_rendering_pipeline(vtk_widget)
        self.create_scene(directory)
        self.render_all()

class MeasurementInteractor(vtk.vtkInteractorStyleTrackballCamera):
    import math
    def __init__(self, parent_viewer=None, mode="Distance"):
        super().__init__()
        self.AddObserver("LeftButtonPressEvent", self.on_left_click)
        # Keep RightButton handlers registered when needed (added dynamically)
        self.points = []
        self.parent_viewer = parent_viewer
        self.mode = mode
        self.drawn_actors = [] 

    def on_left_click(self, obj, event):
        click_pos = self.GetInteractor().GetEventPosition()

        # --- dynamic picker selection ---
        picker = vtk.vtkCellPicker()  # more accurate for geometry and volume
        picker.SetTolerance(0.001)

        # if this is a volume rendering, try a volume picker first
        if (self.parent_viewer and hasattr(self.parent_viewer.vtk_app, "volume")):
            vol_picker = vtk.vtkVolumePicker()
            vol_picker.SetTolerance(0.005)
            vol_picker.Pick(click_pos[0], click_pos[1], 0, self.GetDefaultRenderer())
            picked_pos = vol_picker.GetPickPosition()
            if picked_pos != (0.0, 0.0, 0.0):
                self.points.append(picked_pos)
                self._mark_point(picked_pos)
                self._process_measurement_mode()
                self.OnLeftButtonDown()
                return

        # otherwise, fall back to cell picker (surface or MIP modes)
        picker.Pick(click_pos[0], click_pos[1], 0, self.GetDefaultRenderer())
        picked_pos = picker.GetPickPosition()
        if picked_pos == (0.0, 0.0, 0.0):
            return

        self.points.append(picked_pos)
        self._mark_point(picked_pos)
        self._process_measurement_mode()
        self.OnLeftButtonDown()

    # ---------- PUBLIC finalizer callable by viewer ----------
    def finalize_measurement(self):
        """
        Called by the UI when the user clicks 'Done Measuring'.
        Handles multi-point finalization for Area and Volume.
        """
        # Nothing to do if no points
        if not self.points or len(self.points) == 0:
            return

        if self.mode == "Area":
            self._measure_area(finalize=True)
        elif self.mode == "Volume":
            self._measure_volume(finalize=True)
        # For Distance/Angle/Presets, they auto-calc on click; nothing extra needed.

        # Clear points after finalization
        self.points = []

    # ---------- HELPER FUNCTIONS ----------
    def _mark_point(self, pos):
        sphere = vtk.vtkSphereSource()
        sphere.SetCenter(pos)
        sphere.SetRadius(1.5)
        mapper = vtk.vtkPolyDataMapper()
        mapper.SetInputConnection(sphere.GetOutputPort())
        actor = vtk.vtkActor()
        actor.SetMapper(mapper)
        actor.GetProperty().SetColor(1, 0, 0)
        self.GetDefaultRenderer().AddActor(actor)
        self.drawn_actors.append(actor)
        self.GetInteractor().GetRenderWindow().Render()

    def _get_spacing(self):
        if self.parent_viewer and self.parent_viewer.vtk_app and self.parent_viewer.vtk_app.imageData:
            return self.parent_viewer.vtk_app.imageData.GetSpacing()
        return (1, 1, 1)

    def _measure_distance(self):
        p1, p2 = self.points
        dist = ((p2[0]-p1[0])**2 + (p2[1]-p1[1])**2 + (p2[2]-p1[2])**2) ** 0.5
        spacing = self._get_spacing()
        # approximate pixel equivalent by average spacing
        dist_px = dist / (sum(spacing)/3.0)
        self._draw_line(p1, p2, color=(1, 1, 0))
        self._update_ui(f"Distance: {dist:.2f} mm ({dist_px:.2f} px)")
        self.points.clear()

    def _measure_angle(self):
        p1, p2, p3 = self.points
        v1 = [p1[i]-p2[i] for i in range(3)]
        v2 = [p3[i]-p2[i] for i in range(3)]
        dot = sum(v1[i]*v2[i] for i in range(3))
        mag1 = (sum(v**2 for v in v1))**0.5
        mag2 = (sum(v**2 for v in v2))**0.5
        # protect against numerical domain errors
        cosval = dot / (mag1 * mag2 + 1e-12)
        cosval = max(-1.0, min(1.0, cosval))
        angle_deg = self.math.degrees(self.math.acos(cosval))
        self._draw_line(p1, p2, color=(0, 1, 1))
        self._draw_line(p2, p3, color=(0, 1, 1))
        self._update_ui(f"Angle: {angle_deg:.2f}°")
        self.points.clear()
        
    def _process_measurement_mode(self):
        """Decide when to measure based on current mode and number of points."""
        if self.mode == "Distance" and len(self.points) == 2:
            self._measure_distance()
        elif self.mode == "Angle" and len(self.points) == 3:
            self._measure_angle()
        elif self.mode == "Area":
            if len(self.points) >= 3:
                self.AddObserver("RightButtonPressEvent", self._finalize_area)
        elif self.mode == "Volume":
            if len(self.points) >= 4:
                self.AddObserver("RightButtonPressEvent", self._finalize_volume)


    # ---------- AREA (multi-point) ----------
    def _measure_area(self, finalize=False):
        """
        Compute polygon area using fan triangulation and draw the polygon.
        If finalize==False, function returns without computing — we wait until user confirms.
        """
        # Need at least 3 points
        if len(self.points) < 3:
            return

        if not finalize:
            # Not finalizing yet (user still picking)
            return

        total_area = 0.0
        # Use fan triangulation p0, pi, p{i+1}
        p0 = self.points[0]
        for i in range(1, len(self.points)-1):
            p1 = self.points[i]
            p2 = self.points[i+1]
            tri_area = self._triangle_area(p0, p1, p2)
            total_area += tri_area

        # Draw polygon and update UI
        self._draw_polygon(self.points, color=(0, 0.8, 0.8))
        self._update_ui(f"Area: {total_area:.2f} mm²")

        # clear points handled by caller (finalize_measurement)

        return total_area

    # ---------- VOLUME (multi-point) ----------
    def _measure_volume(self, finalize=False):
        """
        Compute volume by fan tetrahedralization around p0:
        volume = sum(|det([p1-p0, p2-p0, p3-p0])|/6)
        If finalize==False, returns without computing.
        """
        if len(self.points) < 4:
            return

        if not finalize:
            return

        def vec_sub(a, b):
            return (a[0]-b[0], a[1]-b[1], a[2]-b[2])

        def cross(u, v):
            return (u[1]*v[2] - u[2]*v[1],
                    u[2]*v[0] - u[0]*v[2],
                    u[0]*v[1] - u[1]*v[0])

        def dot(u, v):
            return u[0]*v[0] + u[1]*v[1] + u[2]*v[2]

        pts = self.points
        p0 = pts[0]
        total_volume = 0.0
        # Fan tetrahedralization: for i in 1..n-3 take (p0, pi, p{i+1}, p{i+2})
        for i in range(1, len(pts)-2):
            p1 = pts[i]
            p2 = pts[i+1]
            p3 = pts[i+2]
            u = vec_sub(p1, p0)
            v = vec_sub(p2, p0)
            w = vec_sub(p3, p0)
            cross_vw = cross(v, w)
            det = dot(u, cross_vw)
            vol = abs(det) / 6.0
            total_volume += vol
            # For visualization, draw each tetrahedron (semi-transparent)
            self._draw_tetrahedron([p0, p1, p2, p3])

        self._update_ui(f"Volume: {total_volume:.2f} mm³")

        return total_volume

    # ---------- Legacy right-click finalizers kept (call new routines) ----------
    def _finalize_area(self, obj=None, event=None):
        # call new area routine with finalize
        self._measure_area(finalize=True)
        # clear points after finalization
        self.points = []

    def _finalize_volume(self, obj=None, event=None):
        # call new volume routine with finalize
        self._measure_volume(finalize=True)
        # clear points after finalization
        self.points = []

    # ---------- DRAWING HELPERS ----------
    def _draw_line(self, p1, p2, color=(1, 1, 0)):
        line = vtk.vtkLineSource()
        line.SetPoint1(p1)
        line.SetPoint2(p2)
        mapper = vtk.vtkPolyDataMapper()
        mapper.SetInputConnection(line.GetOutputPort())
        actor = vtk.vtkActor()
        actor.SetMapper(mapper)
        actor.GetProperty().SetColor(color)
        actor.GetProperty().SetLineWidth(3)
        self.GetDefaultRenderer().AddActor(actor)
        self.drawn_actors.append(actor)
        self.GetInteractor().GetRenderWindow().Render()

    def _draw_polygon(self, points, color=(0, 1, 0)):
        pts = vtk.vtkPoints()
        polys = vtk.vtkCellArray()
        for i, p in enumerate(points):
            pts.InsertNextPoint(p)
        polygon = vtk.vtkPolygon()
        polygon.GetPointIds().SetNumberOfIds(len(points))
        for i in range(len(points)):
            polygon.GetPointIds().SetId(i, i)
        polys.InsertNextCell(polygon)
        polydata = vtk.vtkPolyData()
        polydata.SetPoints(pts)
        polydata.SetPolys(polys)
        mapper = vtk.vtkPolyDataMapper()
        mapper.SetInputData(polydata)
        actor = vtk.vtkActor()
        actor.SetMapper(mapper)
        actor.GetProperty().SetColor(color)
        actor.GetProperty().SetOpacity(0.4)
        self.GetDefaultRenderer().AddActor(actor)
        self.drawn_actors.append(actor)
        self.GetInteractor().GetRenderWindow().Render()

    def _draw_tetrahedron(self, pts):
        points = vtk.vtkPoints()
        for i, p in enumerate(pts):
            points.InsertNextPoint(p)
        tetra = vtk.vtkTetra()
        for i in range(4):
            tetra.GetPointIds().SetId(i, i)
        cells = vtk.vtkCellArray()
        cells.InsertNextCell(tetra)
        ugrid = vtk.vtkUnstructuredGrid()
        ugrid.SetPoints(points)
        ugrid.InsertNextCell(tetra.GetCellType(), tetra.GetPointIds())
        mapper = vtk.vtkDataSetMapper()
        mapper.SetInputData(ugrid)
        actor = vtk.vtkActor()
        actor.SetMapper(mapper)
        actor.GetProperty().SetColor(1, 0.5, 0)
        actor.GetProperty().SetOpacity(0.3)
        self.GetDefaultRenderer().AddActor(actor)
        self.drawn_actors.append(actor)
        self.GetInteractor().GetRenderWindow().Render()

    def _triangle_area(self, p1, p2, p3):
        v1 = [p2[i] - p1[i] for i in range(3)]
        v2 = [p3[i] - p1[i] for i in range(3)]
        cross = [v1[1]*v2[2]-v1[2]*v2[1],
                 v1[2]*v2[0]-v1[0]*v2[2],
                 v1[0]*v2[1]-v1[1]*v2[0]]
        return 0.5 * (sum(c*c for c in cross))**0.5

    def clear_all_measurements(self):
        """Remove all measurement-related actors (points, lines, shapes)."""
        renderer = self.GetDefaultRenderer()
        if not renderer:
            return
        for actor in self.drawn_actors:
            renderer.RemoveActor(actor)
        self.drawn_actors.clear()
        self.points.clear()
        self.GetInteractor().GetRenderWindow().Render()
        
    def _update_ui(self, msg):
        if self.parent_viewer:
            try:
                self.parent_viewer.current_measurement.setText(msg)
                self.parent_viewer.measurements_list.addItem(msg)
                self.parent_viewer.statusBar().showMessage(msg)
            except Exception:
                # UI may be torn down or not available; ignore safely
                pass
            
class AdvancedDICOMViewer(QMainWindow):
    def __init__(self):
        super().__init__()
        self.vtk_app = None
        self.loaded_datasets = {}
        self.current_dataset_id = None
        self._base_parallel_scale = 1.0
        self.current_scalar_opacity = None
        self.current_color_tf = None
        self.slice_viewer = None
            
        # Initialize UI
        self.setup_ui()
        
        # Setup VTK
        self.initialize_vtk()
        
        # Setup slice viewer
        self.setup_slice_viewer()

    def setup_ui(self):
        """Setup the main user interface with all tabs"""
        self.setWindowTitle("Advanced DICOM Medical Visualizer")
        self.resize(1400, 900)
        self.setMinimumSize(1000, 700)
        
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        main_layout = QHBoxLayout()
        main_layout.setContentsMargins(2, 2, 2, 2)
        main_layout.setSpacing(2)
        central_widget.setLayout(main_layout)
        
        # Create splitter for resizable panels
        splitter = QSplitter(Qt.Horizontal)
        splitter.setChildrenCollapsible(False)
        splitter.setHandleWidth(8)
        
        # Left control panel with tabs
        left_panel = self.create_left_panel()
        left_panel.setMinimumWidth(300)
        left_panel.setMaximumWidth(500)
        splitter.addWidget(left_panel)
        
        # Right 3D viewport
        right_panel = self.create_viewport_panel()
        right_panel.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        splitter.addWidget(right_panel)
        
        splitter.setSizes([350, 1050])
        main_layout.addWidget(splitter)
        
        # Create menus and toolbar
        self.create_menus()
        self.create_toolbar()
        self.create_statusbar()
    
    def setup_slice_viewer(self):
        """Setup the detachable slice viewer"""
        self.slice_viewer = DetachableSliceViewer(self)
        self.addDockWidget(Qt.RightDockWidgetArea, self.slice_viewer)
        
        # Connect signals for synchronization
        self.slice_viewer.sliceChanged.connect(self.on_slice_viewer_slice_changed)
        self.slice_viewer.orientationChanged.connect(self.on_slice_viewer_orientation_changed)
        
        # Initially hide the slice viewer until data is loaded
        self.slice_viewer.setVisible(False)

    def create_left_panel(self):
        """Create the left control panel with tabs"""
        panel = QWidget()
        layout = QVBoxLayout()
        layout.setContentsMargins(3, 3, 3, 3)
        layout.setSpacing(3)
        panel.setLayout(layout)
        
        # Title
        title = QLabel("DICOM Controls")
        title.setFont(QFont("Arial", 10, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("background-color: #2b5797; color: white; padding: 4px; margin-bottom: 3px;")
        title.setMaximumHeight(35)
        layout.addWidget(title)
        
        # Create tab widget
        self.tabs = QTabWidget()
        self.tabs.setTabPosition(QTabWidget.North)
        self.tabs.setDocumentMode(True)
        self.tabs.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        
        # Add all tabs - INCLUDING THE SEGMENTATION TAB
        self.tabs.addTab(self.create_datasets_tab(), "📁 Data")
        self.tabs.addTab(self.create_camera_tab(), "📷 View")
        self.tabs.addTab(self.create_color_tab(), "🎨 Color")
        self.tabs.addTab(self.create_segmentation_tab(), "✂️ Segment")  # Add this line
        self.tabs.addTab(self.create_measurement_tab(), "📐 Measure")
        self.tabs.addTab(self.create_transform_tab(), "🔄 Transform")
        self.tabs.addTab(self.create_rendering_tab(), "🔧 Render")
        
        layout.addWidget(self.tabs)
        return panel
    
    def create_datasets_tab(self):
        """Create datasets management tab"""
        widget = QWidget()
        layout = QVBoxLayout()
        layout.setContentsMargins(5, 5, 5, 5)
        layout.setSpacing(5)
        widget.setLayout(layout)
        
        # Load dataset section
        load_group = QGroupBox("Load Data")
        load_layout = QVBoxLayout()
        load_group.setLayout(load_layout)
        
        load_btn = QPushButton("📁 Load DICOM")
        load_btn.setStyleSheet("""
            QPushButton { 
                background-color: #4CAF50; 
                color: white; 
                font-weight: bold; 
                padding: 6px;
                border: none;
                font-size: 11px;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
        """)
        load_btn.clicked.connect(self.load_dataset)
        load_layout.addWidget(load_btn)
        
        self.dataset_progress = QProgressBar()
        self.dataset_progress.setVisible(False)
        self.dataset_progress.setMaximumHeight(15)
        load_layout.addWidget(self.dataset_progress)
        
        layout.addWidget(load_group)
        
        # Dataset list
        dataset_group = QGroupBox("Datasets")
        dataset_layout = QVBoxLayout()
        dataset_group.setLayout(dataset_layout)
        
        self.dataset_list = QListWidget()
        self.dataset_list.setAlternatingRowColors(True)
        self.dataset_list.setMinimumHeight(120)
        self.dataset_list.setFont(QFont("Arial", 9))
        self.dataset_list.currentRowChanged.connect(self.on_dataset_changed)
        dataset_layout.addWidget(self.dataset_list)
        
        # Dataset actions
        dataset_actions = QHBoxLayout()
        remove_btn = QPushButton("Remove")
        remove_btn.setFont(QFont("Arial", 9))
        remove_btn.clicked.connect(self.remove_dataset)
        clear_btn = QPushButton("Clear All")
        clear_btn.setFont(QFont("Arial", 9))
        clear_btn.clicked.connect(self.clear_datasets)
        
        dataset_actions.addWidget(remove_btn)
        dataset_actions.addWidget(clear_btn)
        dataset_layout.addLayout(dataset_actions)
        
        layout.addWidget(dataset_group)
        
        # Dataset info
        info_group = QGroupBox("Dataset Info")
        info_layout = QVBoxLayout()
        info_group.setLayout(info_layout)
        
        self.dataset_info = QTextEdit()
        self.dataset_info.setMaximumHeight(150)
        self.dataset_info.setReadOnly(True)
        self.dataset_info.setFont(QFont("Consolas", 8))
        self.dataset_info.setStyleSheet("""
            QTextEdit {
                background-color: #f8f9fa;
                border: 1px solid #dee2e6;
                border-radius: 2px;
                padding: 3px;
            }
        """)
        info_layout.addWidget(self.dataset_info)
        
        layout.addWidget(info_group)
        layout.addStretch()
        
        return widget
    
    def create_camera_tab(self):
        """Create camera controls tab"""
        widget = QWidget()
        layout = QVBoxLayout()
        layout.setContentsMargins(5, 5, 5, 5)
        layout.setSpacing(5)
        widget.setLayout(layout)
        
        # Preset views
        preset_group = QGroupBox("Preset Views")
        preset_layout = QVBoxLayout()
        preset_group.setLayout(preset_layout)
        
        views_layout = QHBoxLayout()
        self.axial_btn = QPushButton("Axial")
        self.coronal_btn = QPushButton("Coronal") 
        self.sagittal_btn = QPushButton("Sagittal")
        
        button_style = """
            QPushButton { 
                padding: 4px;
                border: none;
                font-weight: bold;
                font-size: 10px;
            }
            QPushButton:hover {
                opacity: 0.9;
            }
        """
        
        self.axial_btn.setStyleSheet(button_style + "background-color: #2196F3; color: white;")
        self.coronal_btn.setStyleSheet(button_style + "background-color: #4CAF50; color: white;")
        self.sagittal_btn.setStyleSheet(button_style + "background-color: #FF9800; color: white;")
        
        self.axial_btn.clicked.connect(lambda: self.set_camera_view('axial'))
        self.coronal_btn.clicked.connect(lambda: self.set_camera_view('coronal'))
        self.sagittal_btn.clicked.connect(lambda: self.set_camera_view('sagittal'))
        
        views_layout.addWidget(self.axial_btn)
        views_layout.addWidget(self.coronal_btn)
        views_layout.addWidget(self.sagittal_btn)
        
        preset_layout.addLayout(views_layout)
        
        layout.addWidget(preset_group)
        
        # Rotation controls
        rotation_group = QGroupBox("Rotation")
        rotation_layout = QGridLayout()
        rotation_group.setLayout(rotation_layout)
        
        axes = ['X', 'Y', 'Z']
        for i, axis in enumerate(axes):
            label = QLabel(f"{axis}:")
            label.setFont(QFont("Arial", 9))
            rotation_layout.addWidget(label, i, 0)
            
            minus_btn = QPushButton("-45°")
            reset_btn = QPushButton("0°")
            plus_btn = QPushButton("+45°")
            
            for btn in [minus_btn, reset_btn, plus_btn]:
                btn.setFont(QFont("Arial", 9))
                btn.setMaximumWidth(45)
            
            minus_btn.clicked.connect(lambda checked, a=axis.lower(): self.rotate_view(a, -45))
            reset_btn.clicked.connect(lambda checked, a=axis.lower(): self.rotate_view(a, 0))
            plus_btn.clicked.connect(lambda checked, a=axis.lower(): self.rotate_view(a, 45))
            
            rotation_layout.addWidget(minus_btn, i, 1)
            rotation_layout.addWidget(reset_btn, i, 2)
            rotation_layout.addWidget(plus_btn, i, 3)
        
        layout.addWidget(rotation_group)
        
        # Camera properties
        camera_group = QGroupBox("Camera")
        camera_layout = QVBoxLayout()
        camera_group.setLayout(camera_layout)
        
        # Zoom
        zoom_layout = QHBoxLayout()
        zoom_label = QLabel("Zoom:")
        zoom_label.setFont(QFont("Arial", 9))
        zoom_layout.addWidget(zoom_label)
        
        self.zoom_slider = QSlider(Qt.Horizontal)
        self.zoom_slider.setRange(10, 500)
        self.zoom_slider.setValue(100)
        self.zoom_slider.valueChanged.connect(self.on_zoom_changed)
        self.zoom_slider.setMaximumHeight(20)
        zoom_layout.addWidget(self.zoom_slider)
        
        self.zoom_label = QLabel("100%")
        self.zoom_label.setFont(QFont("Arial", 9))
        self.zoom_label.setMinimumWidth(35)
        zoom_layout.addWidget(self.zoom_label)
        camera_layout.addLayout(zoom_layout)
        
        # Reset camera
        reset_btn = QPushButton("Reset Camera")
        reset_btn.setFont(QFont("Arial", 9))
        reset_btn.setStyleSheet("""
            QPushButton { 
                background-color: #f44336; 
                color: white; 
                padding: 4px;
                border: none;
            }
            QPushButton:hover {
                background-color: #da190b;
            }
        """)
        reset_btn.clicked.connect(self.reset_camera)
        camera_layout.addWidget(reset_btn)
        
        layout.addWidget(camera_group)
        layout.addStretch()
        
        return widget
        
    def create_color_tab(self):
        """Create color and illumination controls tab with functional sliders"""
        widget = QWidget()
        layout = QVBoxLayout()
        layout.setContentsMargins(5, 5, 5, 5)
        layout.setSpacing(5)
        widget.setLayout(layout)
        
        # Transfer function presets
        tf_group = QGroupBox("Transfer Function Presets")
        tf_layout = QVBoxLayout()
        tf_group.setLayout(tf_layout)
        
        preset_label = QLabel("Choose Preset:")
        preset_label.setFont(QFont("Arial", 9, QFont.Bold))
        tf_layout.addWidget(preset_label)
        
        self.tf_preset = QComboBox()
        self.tf_preset.setFont(QFont("Arial", 9))
        self.tf_preset.addItems([
            "CT Bone", 
            "CT Soft Tissue", 
            "CT Angio", 
            "MRI Brain", 
            "Grayscale", 
            "Hot Metal", 
            "Custom"
        ])
        self.tf_preset.currentTextChanged.connect(self.on_tf_preset_changed)
        tf_layout.addWidget(self.tf_preset)
        
        # Add a button to apply the preset (more explicit)
        apply_preset_btn = QPushButton("Apply Selected Preset")
        apply_preset_btn.setFont(QFont("Arial", 9))
        apply_preset_btn.clicked.connect(lambda: self.on_tf_preset_changed(self.tf_preset.currentText()))
        tf_layout.addWidget(apply_preset_btn)
        
        layout.addWidget(tf_group)
        
        # Create slider controls with immediate feedback
        def create_slider_control(label, default_value, min_val=0, max_val=100, callback=None, suffix=""):
            slider_layout = QHBoxLayout()
            label_widget = QLabel(f"{label}:")
            label_widget.setFont(QFont("Arial", 9))
            label_widget.setMinimumWidth(80)
            slider_layout.addWidget(label_widget)
            
            slider = QSlider(Qt.Horizontal)
            slider.setRange(min_val, max_val)
            slider.setValue(default_value)
            if callback:
                slider.valueChanged.connect(callback)
            slider.setMaximumHeight(18)
            slider_layout.addWidget(slider)
            
            value_label = QLabel(f"{default_value}{suffix}")
            value_label.setFont(QFont("Arial", 9))
            value_label.setMinimumWidth(35)
            value_label.setAlignment(Qt.AlignRight)
            slider_layout.addWidget(value_label)
            
            return slider_layout, slider, value_label
        
        # Window/Level controls (CT specific)
        wl_group = QGroupBox("Window/Level (CT)")
        wl_layout = QVBoxLayout()
        wl_group.setLayout(wl_layout)
        
        self.window_layout, self.window_slider, self.window_label = create_slider_control(
            "Window", 400, 1, 2000, self.on_window_changed, " HU"
        )
        wl_layout.addLayout(self.window_layout)
        
        self.level_layout, self.level_slider, self.level_label = create_slider_control(
            "Level", 40, -1000, 1000, self.on_level_changed, " HU"
        )
        wl_layout.addLayout(self.level_layout)
        
        layout.addWidget(wl_group)
        
        # Opacity controls
        opacity_group = QGroupBox("Opacity Controls")
        opacity_layout = QVBoxLayout()
        opacity_group.setLayout(opacity_layout)
        
        self.opacity_layout, self.opacity_slider, self.opacity_label = create_slider_control(
            "Overall Opacity", 80, 0, 100, self.on_opacity_changed, "%"
        )
        opacity_layout.addLayout(self.opacity_layout)
        
        # Simple range-based opacity controls instead of tissue-specific
        self.air_layout, self.air_slider, self.air_label = create_slider_control(
            "Air/Lung", 10, 0, 100, self.on_air_opacity_changed, "%"
        )
        opacity_layout.addLayout(self.air_layout)
        
        self.fat_layout, self.fat_slider, self.fat_label = create_slider_control(
            "Fat/Soft Tissue", 60, 0, 100, self.on_fat_opacity_changed, "%"
        )
        opacity_layout.addLayout(self.fat_layout)
        
        self.bone_layout, self.bone_slider, self.bone_label = create_slider_control(
            "Bone", 80, 0, 100, self.on_bone_opacity_changed, "%"
        )
        opacity_layout.addLayout(self.bone_layout)
        
        layout.addWidget(opacity_group)
        
        # Color mapping controls
        color_group = QGroupBox("Color Mapping")
        color_layout = QVBoxLayout()
        color_group.setLayout(color_layout)
        
        self.brightness_layout, self.brightness_slider, self.brightness_label = create_slider_control(
            "Brightness", 50, 0, 100, self.on_brightness_changed, "%"
        )
        color_layout.addLayout(self.brightness_layout)
        
        self.contrast_layout, self.contrast_slider, self.contrast_label = create_slider_control(
            "Contrast", 50, 0, 100, self.on_contrast_changed, "%"
        )
        color_layout.addLayout(self.contrast_layout)
        
        layout.addWidget(color_group)
        
        # Lighting controls
        lighting_group = QGroupBox("Lighting Properties")
        lighting_layout = QVBoxLayout()
        lighting_group.setLayout(lighting_layout)
        
        self.ambient_layout, self.ambient_slider, self.ambient_label = create_slider_control(
            "Ambient", 30, 0, 100, self.on_ambient_changed, "%"
        )
        lighting_layout.addLayout(self.ambient_layout)
        
        self.diffuse_layout, self.diffuse_slider, self.diffuse_label = create_slider_control(
            "Diffuse", 70, 0, 100, self.on_diffuse_changed, "%"
        )
        lighting_layout.addLayout(self.diffuse_layout)
        
        self.specular_layout, self.specular_slider, self.specular_label = create_slider_control(
            "Specular", 40, 0, 100, self.on_specular_changed, "%"
        )
        lighting_layout.addLayout(self.specular_layout)
        
        self.specular_power_layout, self.specular_power_slider, self.specular_power_label = create_slider_control(
            "Specular Power", 10, 1, 100, self.on_specular_power_changed, ""
        )
        lighting_layout.addLayout(self.specular_power_layout)
        
        layout.addWidget(lighting_group)
        
        # Reset buttons
        reset_layout = QHBoxLayout()
        reset_color_btn = QPushButton("Reset Color Settings")
        reset_color_btn.setFont(QFont("Arial", 9))
        reset_color_btn.clicked.connect(self.reset_color_settings)
        
        reset_lighting_btn = QPushButton("Reset Lighting")
        reset_lighting_btn.setFont(QFont("Arial", 9))
        reset_lighting_btn.clicked.connect(self.reset_lighting_settings)
        
        reset_layout.addWidget(reset_color_btn)
        reset_layout.addWidget(reset_lighting_btn)
        layout.addLayout(reset_layout)
        
        layout.addStretch()
        return widget

    def create_measurement_tab(self):
        """Create measurement tools tab"""
        widget = QWidget()
        layout = QVBoxLayout()
        layout.setContentsMargins(5, 5, 5, 5)
        layout.setSpacing(5)
        widget.setLayout(layout)
        
        # Measurement mode
        mode_group = QGroupBox("Measurement Mode")
        mode_layout = QVBoxLayout()
        mode_group.setLayout(mode_layout)
        
        mode_select_layout = QHBoxLayout()
        mode_label = QLabel("Mode:")
        mode_label.setFont(QFont("Arial", 9))
        mode_select_layout.addWidget(mode_label)
        self.measure_mode = QComboBox()
        self.measure_mode.setFont(QFont("Arial", 9))
        self.measure_mode.addItems(["Distance", "Angle", "Area", "Volume"])
        self.measure_mode.currentTextChanged.connect(self.on_measure_mode_changed)
        mode_select_layout.addWidget(self.measure_mode)
        mode_layout.addLayout(mode_select_layout)
        
        layout.addWidget(mode_group)
        
        # Active measurement
        active_group = QGroupBox("Active Measurement")
        active_layout = QVBoxLayout()
        active_group.setLayout(active_layout)
        
        self.measurement_status = QLabel("Click points in the 3D view to measure")
        self.measurement_status.setWordWrap(True)
        self.measurement_status.setFont(QFont("Arial", 9))
        active_layout.addWidget(self.measurement_status)
        
        self.current_measurement = QLabel("No measurement in progress")
        self.current_measurement.setStyleSheet("font-weight: bold; color: #2b5797;")
        self.current_measurement.setFont(QFont("Arial", 9))
        active_layout.addWidget(self.current_measurement)
        
        measure_actions = QHBoxLayout()
        self.start_measure_btn = QPushButton("Start Measurement")
        self.start_measure_btn.setFont(QFont("Arial", 9))
        self.cancel_measure_btn = QPushButton("Cancel")
        self.cancel_measure_btn.setFont(QFont("Arial", 9))
        
        self.start_measure_btn.clicked.connect(self.toggle_measurement)
        self.cancel_measure_btn.clicked.connect(self.cancel_measurement)
        
        measure_actions.addWidget(self.start_measure_btn)
        measure_actions.addWidget(self.cancel_measure_btn)
        active_layout.addLayout(measure_actions)
        
        layout.addWidget(active_group)
        
        # Measurements history
        history_group = QGroupBox("Measurement History")
        history_layout = QVBoxLayout()
        history_group.setLayout(history_layout)
        
        self.measurements_list = QListWidget()
        self.measurements_list.setFont(QFont("Arial", 9))
        history_layout.addWidget(self.measurements_list)
        
        history_actions = QHBoxLayout()
        clear_btn = QPushButton("Clear All")
        clear_btn.setFont(QFont("Arial", 9))
        export_btn = QPushButton("Export...")
        export_btn.setFont(QFont("Arial", 9))
        
        clear_btn.clicked.connect(self.clear_measurements)
        export_btn.clicked.connect(self.export_measurements)
        
        history_actions.addWidget(clear_btn)
        history_actions.addWidget(export_btn)
        history_layout.addLayout(history_actions)
        
        layout.addWidget(history_group)
        layout.addStretch()
        
        return widget
    
    def create_transform_tab(self):
        """Create transformation controls tab"""
        widget = QWidget()
        layout = QVBoxLayout()
        layout.setContentsMargins(5, 5, 5, 5)
        layout.setSpacing(5)
        widget.setLayout(layout)
        
        # Translation
        trans_group = QGroupBox("Translation")
        trans_layout = QVBoxLayout()
        trans_group.setLayout(trans_layout)
        
        # X translation
        x_trans_layout = QHBoxLayout()
        x_label = QLabel("X:")
        x_label.setFont(QFont("Arial", 9))
        x_trans_layout.addWidget(x_label)
        self.x_trans_spin = QDoubleSpinBox()
        self.x_trans_spin.setFont(QFont("Arial", 9))
        self.x_trans_spin.setRange(-1000, 1000)
        self.x_trans_spin.setSuffix(" mm")
        self.x_trans_spin.setValue(0)
        self.x_trans_spin.valueChanged.connect(self.on_translation_changed)
        x_trans_layout.addWidget(self.x_trans_spin)
        trans_layout.addLayout(x_trans_layout)
        
        # Y translation
        y_trans_layout = QHBoxLayout()
        y_label = QLabel("Y:")
        y_label.setFont(QFont("Arial", 9))
        y_trans_layout.addWidget(y_label)
        self.y_trans_spin = QDoubleSpinBox()
        self.y_trans_spin.setFont(QFont("Arial", 9))
        self.y_trans_spin.setRange(-1000, 1000)
        self.y_trans_spin.setSuffix(" mm")
        self.y_trans_spin.setValue(0)
        self.y_trans_spin.valueChanged.connect(self.on_translation_changed)
        y_trans_layout.addWidget(self.y_trans_spin)
        trans_layout.addLayout(y_trans_layout)
        
        # Z translation
        z_trans_layout = QHBoxLayout()
        z_label = QLabel("Z:")
        z_label.setFont(QFont("Arial", 9))
        z_trans_layout.addWidget(z_label)
        self.z_trans_spin = QDoubleSpinBox()
        self.z_trans_spin.setFont(QFont("Arial", 9))
        self.z_trans_spin.setRange(-1000, 1000)
        self.z_trans_spin.setSuffix(" mm")
        self.z_trans_spin.setValue(0)
        self.z_trans_spin.valueChanged.connect(self.on_translation_changed)
        z_trans_layout.addWidget(self.z_trans_spin)
        trans_layout.addLayout(z_trans_layout)
        
        apply_trans_btn = QPushButton("Apply Translation")
        apply_trans_btn.setFont(QFont("Arial", 9))
        apply_trans_btn.clicked.connect(self.apply_translation)
        trans_layout.addWidget(apply_trans_btn)
        
        layout.addWidget(trans_group)
        
        # Rotation
        rot_group = QGroupBox("Rotation")
        rot_layout = QVBoxLayout()
        rot_group.setLayout(rot_layout)
        
        # Rotation angles
        angle_layout = QHBoxLayout()
        x_angle_label = QLabel("X Angle:")
        x_angle_label.setFont(QFont("Arial", 9))
        angle_layout.addWidget(x_angle_label)
        self.x_rot_spin = QDoubleSpinBox()
        self.x_rot_spin.setFont(QFont("Arial", 9))
        self.x_rot_spin.setRange(-180, 180)
        self.x_rot_spin.setSuffix("°")
        self.x_rot_spin.setValue(0)
        self.x_rot_spin.valueChanged.connect(self.on_rotation_changed)
        angle_layout.addWidget(self.x_rot_spin)
        
        angle_layout.addWidget(QLabel("Y Angle:"))
        self.y_rot_spin = QDoubleSpinBox()
        self.y_rot_spin.setFont(QFont("Arial", 9))
        self.y_rot_spin.setRange(-180, 180)
        self.y_rot_spin.setSuffix("°")
        self.y_rot_spin.setValue(0)
        self.y_rot_spin.valueChanged.connect(self.on_rotation_changed)
        angle_layout.addWidget(self.y_rot_spin)
        
        angle_layout.addWidget(QLabel("Z Angle:"))
        self.z_rot_spin = QDoubleSpinBox()
        self.z_rot_spin.setFont(QFont("Arial", 9))
        self.z_rot_spin.setRange(-180, 180)
        self.z_rot_spin.setSuffix("°")
        self.z_rot_spin.setValue(0)
        self.z_rot_spin.valueChanged.connect(self.on_rotation_changed)
        angle_layout.addWidget(self.z_rot_spin)
        rot_layout.addLayout(angle_layout)
        
        apply_rot_btn = QPushButton("Apply Rotation")
        apply_rot_btn.setFont(QFont("Arial", 9))
        apply_rot_btn.clicked.connect(self.apply_rotation)
        rot_layout.addWidget(apply_rot_btn)
        
        layout.addWidget(rot_group)
        
        # Scaling
        scale_group = QGroupBox("Scaling")
        scale_layout = QVBoxLayout()
        scale_group.setLayout(scale_layout)
        
        scale_factor_layout = QHBoxLayout()
        scale_label = QLabel("Scale Factor:")
        scale_label.setFont(QFont("Arial", 9))
        scale_factor_layout.addWidget(scale_label)
        self.scale_spin = QDoubleSpinBox()
        self.scale_spin.setFont(QFont("Arial", 9))
        self.scale_spin.setRange(0.1, 10.0)
        self.scale_spin.setValue(1.0)
        self.scale_spin.setSingleStep(0.1)
        self.scale_spin.valueChanged.connect(self.on_scaling_changed)
        scale_factor_layout.addWidget(self.scale_spin)
        scale_layout.addLayout(scale_factor_layout)
        
        apply_scale_btn = QPushButton("Apply Scaling")
        apply_scale_btn.setFont(QFont("Arial", 9))
        apply_scale_btn.clicked.connect(self.apply_scaling)
        scale_layout.addWidget(apply_scale_btn)
        
        layout.addWidget(scale_group)
        
        # Reset transformations
        reset_btn = QPushButton("Reset All Transformations")
        reset_btn.setFont(QFont("Arial", 9))
        reset_btn.setStyleSheet("QPushButton { background-color: #f44336; color: white; }")
        reset_btn.clicked.connect(self.reset_transformations)
        layout.addWidget(reset_btn)
        
        layout.addStretch()
        return widget
        
    def create_segmentation_tab(self):
        """CORRECT ORGAN SEGMENTATION WITH PROPER HU RANGES"""
        widget = QWidget()
        layout = QVBoxLayout()
        widget.setLayout(layout)
        
        group = QGroupBox("Organ Segmentation - PROPER HU RANGES")
        group_layout = QVBoxLayout()
        group.setLayout(group_layout)
        
        organs_grid = QGridLayout()
        
        organs = [
            ("Bones", 200, 3000, 0, 0),
            ("Lungs", -1000, -600, 0, 1), 
            ("Intestines", -1000, -600, 0, 2),  # Same range as lungs
            ("Liver", 50, 70, 1, 0),
            ("Kidneys", 30, 50, 1, 1),
            ("Heart", 30, 50, 1, 2),
            ("Bladder", -10, 50, 2, 0),
            ("Soft Tissue", -50, 100, 2, 1),
            ("Muscle", 10, 40, 2, 2)
        ]
        
        for name, min_hu, max_hu, row, col in organs:
            btn = QPushButton(f"{name}\n{min_hu}-{max_hu}HU")
            btn.clicked.connect(lambda checked, m=min_hu, ma=max_hu, n=name: self.segment_organ(m, ma, n))
            btn.setMaximumHeight(45)
            btn.setStyleSheet("font-size: 9px;")
            organs_grid.addWidget(btn, row, col)
        
        group_layout.addLayout(organs_grid)
        
        # Custom range with better defaults
        custom_group = QGroupBox("Custom Range (Try these if above don't work)")
        custom_layout = QVBoxLayout()
        custom_group.setLayout(custom_layout)
        
        range_layout = QHBoxLayout()
        range_layout.addWidget(QLabel("HU Range:"))
        self.custom_min = QSpinBox()
        self.custom_min.setRange(-1000, 3000)
        self.custom_min.setValue(-100)  # Better default
        range_layout.addWidget(self.custom_min)
        
        range_layout.addWidget(QLabel("to"))
        self.custom_max = QSpinBox()
        self.custom_max.setRange(-1000, 3000)
        self.custom_max.setValue(100)   # Better default
        range_layout.addWidget(self.custom_max)
        
        custom_btn = QPushButton("Segment Custom Range")
        custom_btn.clicked.connect(self.segment_custom)
        range_layout.addWidget(custom_btn)
        custom_layout.addLayout(range_layout)
        
        # Try these common ranges
        common_layout = QHBoxLayout()
        common_layout.addWidget(QLabel("Quick try:"))
        
        common_ranges = [
            ("All Bone", 150, 3000),
            ("All Soft", -100, 100), 
            ("Air", -1000, -900),
            ("Water", -10, 10)
        ]
        
        for name, min_hu, max_hu in common_ranges:
            btn = QPushButton(name)
            btn.setMaximumHeight(25)
            btn.clicked.connect(lambda checked, m=min_hu, ma=max_hu: self.segment_organ(m, ma, name))
            common_layout.addWidget(btn)
        
        custom_layout.addLayout(common_layout)
        group_layout.addWidget(custom_group)
        
        # Controls
        controls_layout = QHBoxLayout()
        clear_btn = QPushButton("Clear Segmentation")
        toggle_btn = QPushButton("Toggle Volume View")
        
        clear_btn.clicked.connect(self.clear_segmentation)
        toggle_btn.clicked.connect(self.toggle_volume_visibility)
        
        controls_layout.addWidget(clear_btn)
        controls_layout.addWidget(toggle_btn)
        group_layout.addLayout(controls_layout)
        
        # Status with better feedback
        self.seg_status = QLabel("Select an organ or try custom ranges\nBone structures work best")
        self.seg_status.setWordWrap(True)
        group_layout.addWidget(self.seg_status)
        
        layout.addWidget(group)
        layout.addStretch()
        
        return widget

    def segment_organ(self, min_hu, max_hu, organ_name):
        """Segment with better error handling and feedback"""
        if not self.vtk_app or not self.vtk_app.imageData:
            self.seg_status.setText("ERROR: Load DICOM data first!")
            return
            
        try:
            # Clear previous segmentation
            self.clear_segmentation()
            
            # Create threshold
            threshold = vtk.vtkImageThreshold()
            threshold.SetInputData(self.vtk_app.imageData)
            threshold.ThresholdBetween(min_hu, max_hu)
            threshold.SetInValue(1)
            threshold.SetOutValue(0)
            threshold.SetOutputScalarTypeToUnsignedChar()
            threshold.Update()
            
            # Check if we actually found anything
            output = threshold.GetOutput()
            if output.GetPointData().GetScalars().GetRange()[1] == 0:
                self.seg_status.setText(f"NOTHING FOUND in range {min_hu}-{max_hu} HU\nTry a different range")
                return
            
            # Create surface
            marching = vtk.vtkMarchingCubes()
            marching.SetInputConnection(threshold.GetOutputPort())
            marching.SetValue(0, 0.5)
            marching.ComputeNormalsOn()
            marching.Update()
            
            # Check if surface has points
            if marching.GetOutput().GetNumberOfPoints() == 0:
                self.seg_status.setText(f"Range {min_hu}-{max_hu} HU found pixels but no 3D structure\nTry wider range")
                return
            
            # Create actor
            mapper = vtk.vtkPolyDataMapper()
            mapper.SetInputConnection(marching.GetOutputPort())
            mapper.ScalarVisibilityOff()
            
            actor = vtk.vtkActor()
            actor.SetMapper(mapper)
            actor.GetProperty().SetColor(0.9, 0.7, 0.3)  # Gold color - easy to see
            actor.GetProperty().SetOpacity(0.9)
            
            # Add to scene and hide volume
            self.vtk_app.renderer.AddActor(actor)
            if hasattr(self.vtk_app, 'volume') and self.vtk_app.volume:
                self.vtk_app.volume.SetVisibility(False)
            
            self.vtk_app.window.Render()
            
            self.seg_status.setText(f"SUCCESS: {organ_name} segmented ({min_hu}-{max_hu} HU)\nGold surface = segmented structure")
            
        except Exception as e:
            self.seg_status.setText(f"Error: {str(e)}")

    def segment_custom(self):
        """Segment custom HU range"""
        min_hu = self.custom_min.value()
        max_hu = self.custom_max.value()
        self.segment_organ(min_hu, max_hu, f"Custom ({min_hu}-{max_hu} HU)")

    def clear_segmentation(self):
        """Clear segmentation and show volume"""
        if not self.vtk_app:
            return
            
        # Remove all non-volume actors
        actors = self.vtk_app.renderer.GetActors()
        actors.InitTraversal()
        
        actors_to_remove = []
        for i in range(actors.GetNumberOfItems()):
            actor = actors.GetNextActor()
            if actor and actor != getattr(self.vtk_app, 'volume', None):
                actors_to_remove.append(actor)
        
        for actor in actors_to_remove:
            self.vtk_app.renderer.RemoveActor(actor)
        
        # Show main volume
        if hasattr(self.vtk_app, 'volume') and self.vtk_app.volume:
            self.vtk_app.volume.SetVisibility(True)
        
        self.vtk_app.window.Render()
        self.seg_status.setText("Cleared all segmentations")

    def toggle_volume_visibility(self):
        """Toggle between volume and segmentation view"""
        if hasattr(self.vtk_app, 'volume') and self.vtk_app.volume:
            current_visibility = self.vtk_app.volume.GetVisibility()
            self.vtk_app.volume.SetVisibility(not current_visibility)
            self.vtk_app.window.Render()
            
            if current_visibility:
                self.seg_status.setText("Volume hidden - viewing segmentation only")
            else:
                self.seg_status.setText("Volume shown - comparing with segmentation")






        
    def create_rendering_tab(self):
        """Create rendering options tab"""
        widget = QWidget()
        layout = QVBoxLayout()
        layout.setContentsMargins(5, 5, 5, 5)
        layout.setSpacing(5)
        widget.setLayout(layout)
        
        # Rendering mode
        render_group = QGroupBox("Rendering Mode")
        render_layout = QVBoxLayout()
        render_group.setLayout(render_layout)
        
        self.render_mode = QComboBox()
        self.render_mode.setFont(QFont("Arial", 9))
        self.render_mode.addItems(["Volume Rendering", "Surface Rendering", "Maximum Intensity Projection", "Minimum Intensity Projection"])
        self.render_mode.currentTextChanged.connect(self.on_render_mode_changed)
        render_layout.addWidget(self.render_mode)
        
        layout.addWidget(render_group)
        
        # Quality settings
        quality_group = QGroupBox("Quality Settings")
        quality_layout = QVBoxLayout()
        quality_group.setLayout(quality_layout)
        
        quality_label = QLabel("Rendering Quality:")
        quality_label.setFont(QFont("Arial", 9))
        quality_layout.addWidget(quality_label)
        self.quality_slider = QSlider(Qt.Horizontal)
        self.quality_slider.setRange(1, 5)
        self.quality_slider.setValue(3)
        self.quality_slider.valueChanged.connect(self.on_quality_changed)
        self.quality_slider.setMaximumHeight(18)
        quality_layout.addWidget(self.quality_slider)
        
        quality_labels = QHBoxLayout()
        fast_label = QLabel("Fast")
        fast_label.setFont(QFont("Arial", 8))
        quality_labels.addWidget(fast_label)
        quality_labels.addStretch()
        best_label = QLabel("Best")
        best_label.setFont(QFont("Arial", 8))
        quality_labels.addWidget(best_label)
        quality_layout.addLayout(quality_labels)
        
        layout.addWidget(quality_group)
        
        # Save options
        save_group = QGroupBox("Save & Export Options")
        save_layout = QVBoxLayout()
        save_group.setLayout(save_layout)

        save_actions = QGridLayout()

        # Existing buttons
        self.save_settings_btn = QPushButton("Save Settings")
        self.save_settings_btn.setFont(QFont("Arial", 9))
        self.load_settings_btn = QPushButton("Load Settings")
        self.load_settings_btn.setFont(QFont("Arial", 9))
        self.export_image_btn = QPushButton("Export Image")
        self.export_image_btn.setFont(QFont("Arial", 9))
        self.export_highres_btn = QPushButton("Export High-Res")
        self.export_highres_btn.setFont(QFont("Arial", 9))

        # DICOM SAVE BUTTONS
        self.save_dicom_btn = QPushButton("Save DICOM Data")
        self.save_dicom_btn.setFont(QFont("Arial", 9))
        self.save_vis_dicom_btn = QPushButton("Save as DICOM")
        self.save_vis_dicom_btn.setFont(QFont("Arial", 9))
        self.comprehensive_export_btn = QPushButton("Comprehensive Export")
        self.comprehensive_export_btn.setFont(QFont("Arial", 9))

        # Model save/load buttons
        self.save_model_btn = QPushButton("Save Model")
        self.save_model_btn.setFont(QFont("Arial", 9))
        self.load_model_btn = QPushButton("Load Model")
        self.load_model_btn.setFont(QFont("Arial", 9))
        self.save_scene_btn = QPushButton("Save Complete Scene")
        self.save_scene_btn.setFont(QFont("Arial", 9))
        self.load_scene_btn = QPushButton("Load Complete Scene")
        self.load_scene_btn.setFont(QFont("Arial", 9))

        # Connect existing buttons
        self.save_settings_btn.clicked.connect(self.save_settings)
        self.load_settings_btn.clicked.connect(self.load_settings)
        self.export_image_btn.clicked.connect(self.export_image)
        self.export_highres_btn.clicked.connect(self.export_high_resolution_image)

        # Connect DICOM buttons
        self.save_dicom_btn.clicked.connect(self.save_dicom_data)
        self.save_vis_dicom_btn.clicked.connect(self.save_visualization_as_dicom)
        self.comprehensive_export_btn.clicked.connect(self.export_comprehensive)

        # Connect model buttons
        self.save_model_btn.clicked.connect(self.save_model)
        self.load_model_btn.clicked.connect(self.load_model)
        self.save_scene_btn.clicked.connect(self.save_complete_scene)
        self.load_scene_btn.clicked.connect(self.load_complete_scene)

        # Layout the buttons in grid
        save_actions.addWidget(self.save_settings_btn, 0, 0)
        save_actions.addWidget(self.load_settings_btn, 0, 1)
        save_actions.addWidget(self.export_image_btn, 1, 0)
        save_actions.addWidget(self.export_highres_btn, 1, 1)
        save_actions.addWidget(self.save_dicom_btn, 2, 0)
        save_actions.addWidget(self.save_vis_dicom_btn, 2, 1)
        save_actions.addWidget(self.save_model_btn, 3, 0)
        save_actions.addWidget(self.load_model_btn, 3, 1)
        save_actions.addWidget(self.save_scene_btn, 4, 0)
        save_actions.addWidget(self.load_scene_btn, 4, 1)
        save_actions.addWidget(self.comprehensive_export_btn, 5, 0, 1, 2)  # Span two columns

        save_layout.addLayout(save_actions)
        layout.addWidget(save_group)
        
        return widget
    
    def create_viewport_panel(self):
        """Create the main 3D viewport"""
        widget = QWidget()
        layout = QVBoxLayout()
        layout.setContentsMargins(2, 2, 2, 2)
        layout.setSpacing(2)
        widget.setLayout(layout)
        
        # Viewport toolbar
        viewport_toolbar = QHBoxLayout()
        viewport_toolbar.setContentsMargins(0, 0, 0, 3)
        
        viewport_title = QLabel("3D Medical Visualization")
        viewport_title.setFont(QFont("Arial", 11, QFont.Bold))
        viewport_toolbar.addWidget(viewport_title)
        
        viewport_toolbar.addStretch()
        
        viewport_label = QLabel("View:")
        viewport_label.setFont(QFont("Arial", 9))
        viewport_toolbar.addWidget(viewport_label)
        
        self.viewport_mode = QComboBox()
        self.viewport_mode.setFont(QFont("Arial", 9))
        self.viewport_mode.addItems(["3D View", "Axial Slice", "Coronal Slice", "Sagittal Slice"])
        self.viewport_mode.currentTextChanged.connect(self.on_viewport_mode_changed)
        viewport_toolbar.addWidget(self.viewport_mode)
        
        # Toggle slice viewer button
        self.toggle_slice_viewer_btn = QPushButton("📋 Show Slice Viewer")
        self.toggle_slice_viewer_btn.setFont(QFont("Arial", 9))
        self.toggle_slice_viewer_btn.setCheckable(True)
        self.toggle_slice_viewer_btn.setChecked(False)
        self.toggle_slice_viewer_btn.clicked.connect(self.toggle_slice_viewer)
        viewport_toolbar.addWidget(self.toggle_slice_viewer_btn)
        
        layout.addLayout(viewport_toolbar)

        # VTK widget
        self.vtk_widget = QVTKRenderWindowInteractor(widget)
        self.vtk_widget.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.vtk_widget.setMinimumSize(400, 400)
        layout.addWidget(self.vtk_widget)
        
        # Slice controls
        self.slice_controls = QWidget()
        slice_layout = QHBoxLayout()
        self.slice_controls.setLayout(slice_layout)
        
        slice_label = QLabel("Slice:")
        slice_label.setFont(QFont("Arial", 9))
        slice_layout.addWidget(slice_label)
        
        self.slice_slider = QSlider(Qt.Horizontal)
        self.slice_slider.setRange(0, 100)
        self.slice_slider.setValue(50)
        self.slice_slider.valueChanged.connect(self.on_slice_changed)
        self.slice_slider.setMaximumHeight(18)
        slice_layout.addWidget(self.slice_slider)
        
        self.slice_label = QLabel("50/100")
        self.slice_label.setFont(QFont("Arial", 9))
        self.slice_label.setMinimumWidth(40)
        slice_layout.addWidget(self.slice_label)
        
        # Navigation buttons
        nav_layout = QHBoxLayout()
        prev_btn = QPushButton("◀")
        prev_btn.setMaximumWidth(30)
        prev_btn.clicked.connect(self.previous_slice)
        next_btn = QPushButton("▶")
        next_btn.setMaximumWidth(30)
        next_btn.clicked.connect(self.next_slice)
        
        nav_layout.addWidget(prev_btn)
        nav_layout.addWidget(next_btn)
        slice_layout.addLayout(nav_layout)
        
        layout.addWidget(self.slice_controls)
        self.slice_controls.setVisible(False)
        
        return widget

    def create_menus(self):
        """Create menu bar"""
        menubar = self.menuBar()
        
        # File menu
        file_menu = menubar.addMenu('File')
        
        # Add these actions
        save_dicom_action = QAction('Save DICOM Data', self)
        save_dicom_action.setShortcut('Ctrl+D')
        save_dicom_action.triggered.connect(self.save_dicom_data)
        file_menu.addAction(save_dicom_action)

        save_vis_dicom_action = QAction('Save Visualization as DICOM', self)
        save_vis_dicom_action.triggered.connect(self.save_visualization_as_dicom)
        file_menu.addAction(save_vis_dicom_action)

        comprehensive_export_action = QAction('Comprehensive Export', self)
        comprehensive_export_action.setShortcut('Ctrl+E')
        comprehensive_export_action.triggered.connect(self.export_comprehensive)
        file_menu.addAction(comprehensive_export_action)

        # Model save/load actions
        save_model_action = QAction('Save Model', self)
        save_model_action.setShortcut('Ctrl+M')
        save_model_action.triggered.connect(self.save_model)
        file_menu.addAction(save_model_action)

        load_model_action = QAction('Load Model', self)
        load_model_action.setShortcut('Ctrl+O')
        load_model_action.triggered.connect(self.load_model)
        file_menu.addAction(load_model_action)

        save_scene_action = QAction('Save Complete Scene', self)
        save_scene_action.triggered.connect(self.save_complete_scene)
        file_menu.addAction(save_scene_action)

        load_scene_action = QAction('Load Complete Scene', self)
        load_scene_action.triggered.connect(self.load_complete_scene)
        file_menu.addAction(load_scene_action)

        file_menu.addSeparator()
        
        exit_action = QAction('Exit', self)
        exit_action.setShortcut('Ctrl+Q')
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)
        
        # View menu
        view_menu = menubar.addMenu('View')
        
        reset_view_action = QAction('Reset View', self)
        reset_view_action.setShortcut('Ctrl+R')
        reset_view_action.triggered.connect(self.reset_camera)
        view_menu.addAction(reset_view_action)
        
        view_menu.addSeparator()
        
        axial_action = QAction('Axial View', self)
        axial_action.triggered.connect(lambda: self.set_camera_view('axial'))
        view_menu.addAction(axial_action)
        
        coronal_action = QAction('Coronal View', self)
        coronal_action.triggered.connect(lambda: self.set_camera_view('coronal'))
        view_menu.addAction(coronal_action)
        
        sagittal_action = QAction('Sagittal View', self)
        sagittal_action.triggered.connect(lambda: self.set_camera_view('sagittal'))
        view_menu.addAction(sagittal_action)
        
        view_menu.addSeparator()
        
        # Slice view actions
        axial_slice_action = QAction('Axial Slice', self)
        axial_slice_action.triggered.connect(lambda: self.on_viewport_mode_changed('Axial Slice'))
        view_menu.addAction(axial_slice_action)
        
        coronal_slice_action = QAction('Coronal Slice', self)
        coronal_slice_action.triggered.connect(lambda: self.on_viewport_mode_changed('Coronal Slice'))
        view_menu.addAction(coronal_slice_action)
        
        sagittal_slice_action = QAction('Sagittal Slice', self)
        sagittal_slice_action.triggered.connect(lambda: self.on_viewport_mode_changed('Sagittal Slice'))
        view_menu.addAction(sagittal_slice_action)
        
        view_menu.addSeparator()
        
        # Slice viewer toggle
        toggle_slice_viewer_action = QAction('Toggle Slice Viewer', self)
        toggle_slice_viewer_action.setShortcut('Ctrl+2')
        toggle_slice_viewer_action.triggered.connect(self.toggle_slice_viewer)
        view_menu.addAction(toggle_slice_viewer_action)
        
        # Tools menu
        tools_menu = menubar.addMenu('Tools')
        
        measure_action = QAction('Measurement Tool', self)
        measure_action.setShortcut('Ctrl+M')
        measure_action.triggered.connect(self.start_measurement)
        tools_menu.addAction(measure_action)
        
        # Help menu
        help_menu = menubar.addMenu('Help')
        
        help_action = QAction('Help Contents', self)
        help_action.setShortcut('F1')
        help_action.triggered.connect(self.show_help)
        help_menu.addAction(help_action)
        
        about_action = QAction('About', self)
        about_action.triggered.connect(self.show_about)
        help_menu.addAction(about_action)
    
    def create_toolbar(self):
        """Create main toolbar"""
        toolbar = self.addToolBar('Main Toolbar')
        toolbar.setMovable(False)
        toolbar.setIconSize(QSize(20, 20))
        toolbar.setToolButtonStyle(Qt.ToolButtonIconOnly)
        toolbar.setMaximumHeight(35)
        
        button_style = """
            QPushButton {
                padding: 3px 6px;
                margin: 1px;
                border: 1px solid #ccc;
                border-radius: 2px;
                background-color: #f8f9fa;
                font-size: 10px;
            }
            QPushButton:hover {
                background-color: #e9ecef;
            }
        """
        
        # Dataset controls
        load_btn = QPushButton("📁")
        load_btn.setToolTip("Load Dataset")
        load_btn.setStyleSheet(button_style)
        load_btn.clicked.connect(self.load_dataset)
        toolbar.addWidget(load_btn)
        
        toolbar.addSeparator()
        
        # View controls
        reset_btn = QPushButton("🔄")
        reset_btn.setToolTip("Reset View")
        reset_btn.setStyleSheet(button_style)
        reset_btn.clicked.connect(self.reset_camera)
        toolbar.addWidget(reset_btn)
        
        toolbar.addSeparator()
        
        # Slice viewer button
        self.slice_viewer_btn = QPushButton("📋")
        self.slice_viewer_btn.setToolTip("Toggle Slice Viewer (Ctrl+2)")
        self.slice_viewer_btn.setStyleSheet(button_style)
        self.slice_viewer_btn.setCheckable(True)
        self.slice_viewer_btn.setChecked(False)
        self.slice_viewer_btn.clicked.connect(self.toggle_slice_viewer)
        toolbar.addWidget(self.slice_viewer_btn)
        
        toolbar.addSeparator()
        
        # Measurement tools
        measure_btn = QPushButton("📐")
        measure_btn.setToolTip("Measure")
        measure_btn.setStyleSheet(button_style)
        measure_btn.clicked.connect(self.start_measurement)
        toolbar.addWidget(measure_btn)
        
        toolbar.addSeparator()
        
        # Save/Export
        save_btn = QPushButton("💾")
        save_btn.setToolTip("Save")
        save_btn.setStyleSheet(button_style)
        save_btn.clicked.connect(self.save_model)
        toolbar.addWidget(save_btn)
        
        export_btn = QPushButton("📤")
        export_btn.setToolTip("Export")
        export_btn.setStyleSheet(button_style)
        export_btn.clicked.connect(self.export_image)
        toolbar.addWidget(export_btn)
        
        toolbar.addSeparator()
        
        # Help
        help_btn = QPushButton("❓")
        help_btn.setToolTip("Help")
        help_btn.setStyleSheet(button_style)
        help_btn.clicked.connect(self.show_help)
        toolbar.addWidget(help_btn)
        
        # Fullscreen toggle button
        fullscreen_btn = QPushButton("⛶")
        fullscreen_btn.setToolTip("Toggle Fullscreen (F11)")
        fullscreen_btn.setStyleSheet(button_style)
        fullscreen_btn.clicked.connect(self.toggle_fullscreen)
        toolbar.addWidget(fullscreen_btn)
    
    def create_statusbar(self):
        """Create status bar"""
        self.statusBar().showMessage("Ready - No dataset loaded")
        
        # Add permanent widgets to status bar
        self.dataset_status = QLabel("No dataset")
        self.dataset_status.setFont(QFont("Arial", 9))
        self.memory_status = QLabel("Memory: --")
        self.memory_status.setFont(QFont("Arial", 9))
        self.rendering_status = QLabel("Rendering: --")
        self.rendering_status.setFont(QFont("Arial", 9))
        
        self.statusBar().addPermanentWidget(self.dataset_status)
        self.statusBar().addPermanentWidget(self.memory_status)
        self.statusBar().addPermanentWidget(self.rendering_status)

    # ========== CORE FUNCTIONALITY METHODS ==========

    def initialize_vtk(self):
        try:
            print("Initializing VTK...")
            self.vtk_app = myVTK()
            self.vtk_app.start(self.vtk_widget)
            print("VTK initialized successfully")
        except Exception as e:
            print(f"Error initializing VTK: {e}")
            QMessageBox.critical(self, "VTK Error", f"Failed to initialize 3D viewer: {str(e)}")

    def toggle_slice_viewer(self):
        """Toggle slice viewer visibility"""
        if self.slice_viewer:
            visible = not self.slice_viewer.isVisible()
            self.slice_viewer.setVisible(visible)
            self.slice_viewer_btn.setChecked(visible)
            self.toggle_slice_viewer_btn.setChecked(visible)
            
            if visible and self.vtk_app and self.vtk_app.imageData:
                self.slice_viewer.set_slice_data(self.vtk_app)
                self.statusBar().showMessage("Slice viewer shown - drag to detach")
            elif visible:
                self.statusBar().showMessage("Load a dataset to use slice viewer")
            else:
                self.statusBar().showMessage("Slice viewer hidden")

    def load_dataset(self):
        try:
            directory = QFileDialog.getExistingDirectory(
                self, 
                "Select DICOM Directory",
                "",
                QFileDialog.ShowDirsOnly
            )
            
            if not directory:
                return
                
            self.statusBar().showMessage(f"Loading DICOM dataset from: {directory}")
            self.dataset_progress.setVisible(True)
            self.dataset_progress.setValue(10)
            
            if not os.path.exists(directory):
                QMessageBox.warning(self, "Directory Error", "Selected directory does not exist")
                self.dataset_progress.setVisible(False)
                return
                
            dataset_name = os.path.basename(directory)
            if not dataset_name or dataset_name == ".":
                dataset_name = "DICOM Dataset"
                
            self.dataset_progress.setValue(30)
            
            # Add to dataset list
            self.dataset_list.addItem(f"{dataset_name}")
            
            # Store dataset information
            dataset_id = f"dataset_{len(self.loaded_datasets)}"
            self.loaded_datasets[dataset_id] = {
                'name': dataset_name,
                'path': directory,
                'loaded': False
            }
            
            self.dataset_progress.setValue(60)
            
            # Load the dataset
            success = self.load_dicom_with_myvtk(directory, dataset_name)
            
            if success:
                self.dataset_progress.setValue(100)
                self.statusBar().showMessage(f"Successfully loaded DICOM dataset: {dataset_name}")
                self.loaded_datasets[dataset_id]['loaded'] = True
                self.dataset_list.setCurrentRow(self.dataset_list.count() - 1)
                
                # Setup slice viewer with loaded data
                if self.slice_viewer:
                    self.slice_viewer.set_slice_data(self.vtk_app)
                    if not self.slice_viewer.isVisible():
                        self.toggle_slice_viewer()
            else:
                self.dataset_list.takeItem(self.dataset_list.count() - 1)
                QMessageBox.warning(self, "Loading Failed", "Failed to load DICOM dataset.")
                
        except Exception as e:
            QMessageBox.critical(self, "Loading Error", f"Failed to load DICOM dataset: {str(e)}")
            self.statusBar().showMessage("Error loading dataset")
        finally:
            self.dataset_progress.setVisible(False)

    def load_dicom_with_myvtk(self, directory, dataset_name):
        """Load DICOM data using the integrated myVTK class"""
        try:
            print(f"Loading DICOM: {directory}")
            
            # Reload scene with new directory
            self.vtk_app.create_scene(directory)
            self.vtk_app.render_all()

            # Clear cached zoom values
            if hasattr(self, '_base_parallel_scale'):
                del self._base_parallel_scale
            if hasattr(self, '_base_distance'):
                del self._base_distance

            # Reset zoom to 100%
            self.zoom_slider.setValue(100)
            self.zoom_label.setText("100%")
            
            # SIMPLIFIED: Check if we have a renderer and volume property
            volume_loaded = False
            if (hasattr(self.vtk_app, 'renderer') and self.vtk_app.renderer and
                hasattr(self.vtk_app, 'volumeProperty') and self.vtk_app.volumeProperty):
                
                # Check if there are any actors in the renderer
                actors = self.vtk_app.renderer.GetActors()
                if actors.GetNumberOfItems() > 0:
                    volume_loaded = True
                    print("DICOM loaded successfully - renderer has actors")
                else:
                    print("Renderer has no actors")
            else:
                print("Renderer or volume property not available")
            
            if not volume_loaded:
                print("Volume loading check failed")
                return False
            
            # Initialize color controls with default preset
            if hasattr(self, 'tf_preset'):
                # Set the preset but don't trigger the change event yet
                self.tf_preset.blockSignals(True)
                self.tf_preset.setCurrentText("CT Bone")
                self.tf_preset.blockSignals(False)
                # Now apply the preset
                self.on_tf_preset_changed("CT Bone")
                
            # Update UI with dataset info
            self.update_dataset_info_detailed({
                'name': dataset_name,
                'path': directory,
                'loaded': True
            })
            
            # Update the dataset status in status bar
            self.dataset_status.setText(f"Loaded: {dataset_name}")
            
            print("DICOM load completed successfully")
            return True
            
        except Exception as e:
            print(f"Error loading DICOM data: {str(e)}")
            import traceback
            traceback.print_exc()
            return False

    def update_dataset_info_detailed(self, dataset_info):
        """Update dataset information with detailed metadata"""
        info_text = f"""
        Dataset: {dataset_info['name']}
        Path: {dataset_info.get('path', 'Not specified')}
        
        Status: {'Loaded' if dataset_info.get('loaded', False) else 'Not Loaded'}
        
        Use the view controls to navigate and explore the 3D volume.
        Color tab controls are now available for transfer function adjustment.
        """
        self.dataset_info.setText(info_text.strip())
        # Also update the status bar
        self.dataset_status.setText(f"Loaded: {dataset_info['name']}")

    def on_dataset_changed(self, row):
        if row >= 0:
            item = self.dataset_list.item(row)
            dataset_name = item.text()
            
            # Find the dataset info
            for dataset_id, info in self.loaded_datasets.items():
                if info['name'] == dataset_name:
                    self.update_dataset_info_detailed(info)
                    self.statusBar().showMessage(f"Switched to dataset: {info['name']}")
                    
                    # Reload the dataset in the viewer if it has a path
                    if self.vtk_app is not None and 'path' in info and info['path']:
                        self.vtk_app.create_scene(info['path'])
                        self.vtk_app.render_all()
                        
                        # Update slice viewer
                        if self.slice_viewer and self.slice_viewer.isVisible():
                            self.slice_viewer.set_slice_data(self.vtk_app)
                    self.current_dataset_id = dataset_id
                    break

    def remove_dataset(self):
        current_row = self.dataset_list.currentRow()
        if current_row >= 0:
            item = self.dataset_list.takeItem(current_row)
            dataset_name = item.text()
            
            # Remove from loaded_datasets
            for dataset_id, info in list(self.loaded_datasets.items()):
                if info['name'] == dataset_name:
                    del self.loaded_datasets[dataset_id]
                    break
            
            # Clear the 3D view if we removed the currently displayed dataset
            if self.vtk_app is not None:
                self.vtk_app.create_scene()
                self.vtk_app.render_all()
            
            self.statusBar().showMessage(f"Removed dataset: {dataset_name}")
            
            # If there are still datasets, select the first one
            if self.dataset_list.count() > 0:
                self.dataset_list.setCurrentRow(0)
            else:
                self.current_dataset_id = None

    def clear_datasets(self):
        self.dataset_list.clear()
        self.loaded_datasets.clear()
        
        # Clear the 3D view
        if self.vtk_app is not None:
            self.vtk_app.create_scene()
            self.vtk_app.render_all()
        
        self.statusBar().showMessage("All datasets cleared")

    def reset_camera(self):
        """Reset camera and zoom to default"""
        if self.vtk_app is not None and self.vtk_app.renderer is not None:
            print("Resetting camera and zoom...")
            
            # Reset the camera view
            self.vtk_app.reset_view()
            
            # Clear cached values
            if hasattr(self, '_base_parallel_scale'):
                del self._base_parallel_scale
            if hasattr(self, '_base_distance'):
                del self._base_distance
            
            # Reset zoom slider to 100%
            self.zoom_slider.setValue(100)
            self.zoom_label.setText("100%")
            
            # Force a render to update the view
            self.vtk_app.window.Render()
            self.statusBar().showMessage("Camera and zoom reset to default")

    def on_zoom_changed(self, value):
        """Handle zoom slider changes in real-time"""
        self.zoom_label.setText(f"{value}%")
        
        # Process zoom immediately without debouncing for real-time response
        self.process_zoom_immediate(value)

    def process_zoom_immediate(self, value):
        """Process zoom immediately without delay"""
        if self.vtk_app is not None and self.vtk_app.renderer is not None:
            camera = self.vtk_app.renderer.GetActiveCamera()
            
            # Convert slider value to zoom factor
            zoom_factor = value / 100.0
            
            if camera.GetParallelProjection():
                # For parallel projection - use parallel scale
                if not hasattr(self, '_base_parallel_scale'):
                    # Initialize base scale on first zoom
                    if hasattr(self.vtk_app, 'volume') and self.vtk_app.volume:
                        bounds = self.vtk_app.volume.GetBounds()
                        size_y = bounds[3] - bounds[2]
                        self._base_parallel_scale = size_y / 2.0
                    else:
                        self._base_parallel_scale = camera.GetParallelScale()
                
                new_scale = self._base_parallel_scale / zoom_factor
                camera.SetParallelScale(max(new_scale, 0.1))  # Prevent zero or negative scale
            else:
                # For perspective projection - use camera distance
                focal_point = camera.GetFocalPoint()
                position = camera.GetPosition()
                
                # Calculate current distance
                current_distance = ((position[0]-focal_point[0])**2 + 
                                (position[1]-focal_point[1])**2 + 
                                (position[2]-focal_point[2])**2)**0.5
                
                if not hasattr(self, '_base_distance'):
                    self._base_distance = current_distance
                
                # Calculate new distance
                new_distance = self._base_distance / zoom_factor
                
                # Calculate direction vector
                direction = [
                    position[0] - focal_point[0],
                    position[1] - focal_point[1],
                    position[2] - focal_point[2]
                ]
                
                # Normalize and set new position
                length = (direction[0]**2 + direction[1]**2 + direction[2]**2)**0.5
                if length > 0:
                    direction = [d/length for d in direction]
                    new_position = [
                        focal_point[0] + direction[0] * new_distance,
                        focal_point[1] + direction[1] * new_distance,
                        focal_point[2] + direction[2] * new_distance
                    ]
                    camera.SetPosition(new_position)
            
            # Reset clipping range and render
            self.vtk_app.renderer.ResetCameraClippingRange()
            self.vtk_app.window.Render()

    def rotate_view(self, axis, angle):
        """Use VTK's built-in orbit methods for proper rotation"""
        if self.vtk_app is not None and self.vtk_app.renderer is not None:
            camera = self.vtk_app.renderer.GetActiveCamera()
            
            print(f"Rotating {axis}-axis by {angle}°")
            
            if axis.lower() == 'x':
                # For medical viewing, X rotation should be elevation (up/down)
                camera.Elevation(angle)
            elif axis.lower() == 'y':
                # Y rotation should be azimuth (left/right)
                camera.Azimuth(angle)
            elif axis.lower() == 'z':
                # Z rotation is roll
                camera.Roll(angle)
            
            self.vtk_app.window.Render()
            self.statusBar().showMessage(f"Rotated {axis}-axis by {angle}°")

    def set_camera_view(self, view_type):
        if self.vtk_app is None or self.vtk_app.renderer is None:
            return
            
        camera = self.vtk_app.renderer.GetActiveCamera()
        
        # Get volume bounds to set appropriate distance
        if hasattr(self.vtk_app, 'volume') and self.vtk_app.volume:
            bounds = self.vtk_app.volume.GetBounds()
            size_x = bounds[1] - bounds[0]
            size_y = bounds[3] - bounds[2] 
            size_z = bounds[5] - bounds[4]
            max_size = max(size_x, size_y, size_z)
            distance = max_size * 1.5
        else:
            distance = 300
        
        if view_type.lower() == 'axial':
            camera.SetPosition(0, 0, distance)
            camera.SetFocalPoint(0, 0, 0)
            camera.SetViewUp(0, 1, 0)
        elif view_type.lower() == 'coronal':
            camera.SetPosition(0, distance, 0)
            camera.SetFocalPoint(0, 0, 0)
            camera.SetViewUp(0, 0, 1)
        elif view_type.lower() == 'sagittal':
            camera.SetPosition(distance, 0, 0)
            camera.SetFocalPoint(0, 0, 0)
            camera.SetViewUp(0, 0, 1)
        
        self.vtk_app.renderer.ResetCamera()
        self.vtk_app.window.Render()
        self.statusBar().showMessage(f"Set {view_type} view")

    # ========== SLICE VIEWING METHODS ==========

    def on_viewport_mode_changed(self, mode):
        """Handle viewport mode changes (3D view vs slice views)"""
        if self.vtk_app is None:
            return
            
        self.slice_controls.setVisible(mode != "3D View")
        
        if mode == "3D View":
            # Switch back to volume rendering
            self.vtk_app.remove_slice_actors()
            self.vtk_app.current_slice_mode = None
            self.vtk_app.renderer.ResetCamera()
        else:
            # Switch to slice view
            orientation = mode.split()[0].lower()  # 'axial', 'coronal', 'sagittal'
            self.show_slice_view(orientation)
        
        self.vtk_app.window.Render()
        self.statusBar().showMessage(f"Viewport mode: {mode}")

    def show_slice_view(self, orientation):
        """Show slice view for the given orientation"""
        if self.vtk_app is None or self.vtk_app.imageData is None:
            QMessageBox.warning(self, "No Data", "No DICOM data loaded")
            return
            
        # Get current slice number for this orientation
        current_slice = self.vtk_app.slice_number.get(orientation, 0)
        max_slices = self.vtk_app.max_slices.get(orientation, 0)
        
        # Update slice slider range and value
        self.slice_slider.setRange(0, max_slices)
        self.slice_slider.setValue(current_slice)
        self.update_slice_label(current_slice, max_slices)
        
        # Show the slice
        success = self.vtk_app.show_slice(orientation, current_slice)
        if success:
            self.statusBar().showMessage(f"Showing {orientation} slice {current_slice}/{max_slices}")
            
            # Sync with slice viewer if enabled
            if (self.slice_viewer and self.slice_viewer.isVisible() and 
                self.slice_viewer.sync_checkbox.isChecked()):
                self.slice_viewer.set_slice(orientation, current_slice)
        else:
            self.statusBar().showMessage(f"Failed to show {orientation} slice")

    def on_slice_changed(self, value):
        """Handle slice slider changes"""
        if self.vtk_app is None or self.vtk_app.current_slice_mode is None:
            return
            
        orientation = self.vtk_app.current_slice_mode
        max_slices = self.vtk_app.max_slices.get(orientation, 0)
        
        # Update slice label
        self.update_slice_label(value, max_slices)
        
        # Show the new slice
        success = self.vtk_app.show_slice(orientation, value)
        if success:
            self.statusBar().showMessage(f"Showing {orientation} slice {value}/{max_slices}")
            
            # Sync with slice viewer if enabled
            if (self.slice_viewer and self.slice_viewer.isVisible() and 
                self.slice_viewer.sync_checkbox.isChecked()):
                self.slice_viewer.set_slice(orientation, value)
                
    def on_slice_viewer_slice_changed(self, value):
        """Handle slice changes from slice viewer"""
        if (self.vtk_app and self.vtk_app.current_slice_mode and
            self.slice_viewer and self.slice_viewer.sync_checkbox.isChecked()):
            
            orientation = self.vtk_app.current_slice_mode
            if orientation == self.slice_viewer.current_orientation:
                self.slice_slider.setValue(value)
                
    def on_slice_viewer_orientation_changed(self, orientation):
        """Handle orientation changes from slice viewer"""
        if (self.vtk_app and self.slice_viewer and 
            self.slice_viewer.sync_checkbox.isChecked()):
            
            # Update main viewport if it's in slice mode
            if self.vtk_app.current_slice_mode:
                viewport_mode = f"{orientation.capitalize()} Slice"
                self.viewport_mode.setCurrentText(viewport_mode)

    def update_slice_label(self, current, maximum):
        """Update the slice label text"""
        self.slice_label.setText(f"{current}/{maximum}")

    def previous_slice(self):
        """Navigate to previous slice"""
        if self.vtk_app is None or self.vtk_app.current_slice_mode is None:
            return
            
        current_value = self.slice_slider.value()
        if current_value > 0:
            self.slice_slider.setValue(current_value - 1)

    def next_slice(self):
        """Navigate to next slice"""
        if self.vtk_app is None or self.vtk_app.current_slice_mode is None:
            return
            
        current_value = self.slice_slider.value()
        max_value = self.slice_slider.maximum()
        if current_value < max_value:
            self.slice_slider.setValue(current_value + 1)

    # ========== TRANSFORMATION METHODS ==========

    def on_translation_changed(self):
        """Handle translation changes"""
        if self.vtk_app is None:
            return
            
        x = self.x_trans_spin.value()
        y = self.y_trans_spin.value()
        z = self.z_trans_spin.value()
        
        self.vtk_app.apply_translation(x, y, z)
        self.vtk_app.window.Render()
        
        # Update slice viewer
        if self.slice_viewer and self.slice_viewer.isVisible():
            self.slice_viewer.update_slice_view()
            
        self.statusBar().showMessage(f"Applied translation: X={x}, Y={y}, Z={z} mm")

    def on_rotation_changed(self):
        """Handle rotation changes"""
        if self.vtk_app is None:
            return
            
        x = self.x_rot_spin.value()
        y = self.y_rot_spin.value()
        z = self.z_rot_spin.value()
        
        self.vtk_app.apply_rotation(x, y, z)
        self.vtk_app.window.Render()
        
        # Update slice viewer
        if self.slice_viewer and self.slice_viewer.isVisible():
            self.slice_viewer.update_slice_view()
            
        self.statusBar().showMessage(f"Applied rotation: X={x}°, Y={y}°, Z={z}°")

    def on_scaling_changed(self):
        """Handle scaling changes"""
        if self.vtk_app is None:
            return
            
        scale = self.scale_spin.value()
        
        self.vtk_app.apply_scaling(scale)
        self.vtk_app.window.Render()
        
        # Update slice viewer
        if self.slice_viewer and self.slice_viewer.isVisible():
            self.slice_viewer.update_slice_view()
            
        self.statusBar().showMessage(f"Applied scaling: {scale}x")

    def apply_translation(self):
        """Apply translation explicitly"""
        self.on_translation_changed()

    def apply_rotation(self):
        """Apply rotation explicitly"""
        self.on_rotation_changed()

    def apply_scaling(self):
        """Apply scaling explicitly"""
        self.on_scaling_changed()

    def reset_transformations(self):
        """Reset all transformations"""
        if self.vtk_app is None:
            return
            
        # Reset spin boxes
        self.x_trans_spin.setValue(0)
        self.y_trans_spin.setValue(0)
        self.z_trans_spin.setValue(0)
        self.x_rot_spin.setValue(0)
        self.y_rot_spin.setValue(0)
        self.z_rot_spin.setValue(0)
        self.scale_spin.setValue(1.0)
        
        # Reset VTK transformations
        self.vtk_app.reset_transformations()
        self.vtk_app.window.Render()
        
        # Update slice viewer
        if self.slice_viewer and self.slice_viewer.isVisible():
            self.slice_viewer.update_slice_view()
            
        self.statusBar().showMessage("All transformations reset")

    def show_help(self):
        help_dialog = HelpDialog(self)
        help_dialog.exec_()

    def show_about(self):
        QMessageBox.about(self, "About Advanced DICOM Medical Visualizer",
            "Advanced DICOM Medical Visualizer\n\n"
            "Version 2.0\n"
            "Developed for SDV Assignment 2\n\n"
            "Features VTK-based 3D medical visualization\n"
            "with PyQt5 user interface.\n\n"
            "-ABB-2025")

    def toggle_fullscreen(self):
        if self.isFullScreen():
            self.showNormal()
            self.statusBar().showMessage("Exited fullscreen mode")
        else:
            self.showFullScreen()
            self.statusBar().showMessage("Entered fullscreen mode - Press F11 to exit")

    # ========== TAB CONTROL METHODS ==========

    def on_tf_preset_changed(self, preset):
        """Apply transfer function preset that works WITH opacity controls"""
        if self.vtk_app is None or not hasattr(self.vtk_app, 'volumeProperty'):
            return
            
        self.statusBar().showMessage(f"Applying preset: {preset}")
        
        # Store the selected preset
        self.current_preset = preset
        
        # Apply the preset, but respect the current opacity slider values
        self.apply_current_transfer_function()
        
        # Update slice viewer
        if self.slice_viewer and self.slice_viewer.isVisible():
            self.slice_viewer.update_slice_view()
        
    def apply_current_transfer_function(self):
        """Apply transfer function combining preset + opacity controls"""
        if self.vtk_app is None or not hasattr(self.vtk_app, 'volumeProperty'):
            return
            
        if not hasattr(self, 'current_preset'):
            self.current_preset = "CT Bone"
        
        # Get current opacity values from sliders
        air_opacity = self.air_slider.value() / 100.0
        fat_opacity = self.fat_slider.value() / 100.0  
        bone_opacity = self.bone_slider.value() / 100.0
        
        # Create base transfer function based on preset
        scalarOpacity = vtk.vtkPiecewiseFunction()
        color = vtk.vtkColorTransferFunction()
        
        if self.current_preset == "CT Bone":
            # Base bone preset, scaled by opacity sliders
            scalarOpacity.AddPoint(-1000, 0.0)
            scalarOpacity.AddPoint(-200, 0.0)
            scalarOpacity.AddPoint(100, 0.1 * fat_opacity)
            scalarOpacity.AddPoint(300, 0.8 * bone_opacity)
            scalarOpacity.AddPoint(500, 1.0 * bone_opacity)
            
            color.AddRGBPoint(-1000, 0.0, 0.0, 0.0)
            color.AddRGBPoint(-200, 0.3, 0.3, 0.3)
            color.AddRGBPoint(100, 0.8, 0.6, 0.4)
            color.AddRGBPoint(300, 0.9, 0.8, 0.7)
            color.AddRGBPoint(500, 1.0, 1.0, 1.0)
            
        elif self.current_preset == "CT Soft Tissue":
            # Base soft tissue preset, scaled by opacity sliders
            scalarOpacity.AddPoint(-1000, 0.0)
            scalarOpacity.AddPoint(-400, 0.1 * air_opacity)
            scalarOpacity.AddPoint(-50, 0.8 * fat_opacity)
            scalarOpacity.AddPoint(100, 1.0 * fat_opacity)
            scalarOpacity.AddPoint(300, 0.3 * bone_opacity)
            
            color.AddRGBPoint(-1000, 0.0, 0.0, 0.0)
            color.AddRGBPoint(-400, 0.2, 0.2, 0.8)
            color.AddRGBPoint(-50, 0.9, 0.7, 0.3)
            color.AddRGBPoint(100, 0.8, 0.5, 0.5)
            color.AddRGBPoint(300, 0.9, 0.9, 0.9)
            
        elif self.current_preset == "CT Angio":
            # Base angio preset, scaled by opacity sliders
            scalarOpacity.AddPoint(-1000, 0.0)
            scalarOpacity.AddPoint(0, 0.0)
            scalarOpacity.AddPoint(100, 0.9 * fat_opacity)
            scalarOpacity.AddPoint(300, 1.0 * fat_opacity)
            
            color.AddRGBPoint(-1000, 0.0, 0.0, 0.0)
            color.AddRGBPoint(0, 0.0, 0.0, 0.0)
            color.AddRGBPoint(100, 0.8, 0.1, 0.1)
            color.AddRGBPoint(300, 1.0, 0.0, 0.0)
            
        elif self.current_preset == "MRI Brain":
            # Base MRI preset
            scalarOpacity.AddPoint(0, 0.0)
            scalarOpacity.AddPoint(100, 0.1 * fat_opacity)
            scalarOpacity.AddPoint(500, 0.8 * fat_opacity)
            scalarOpacity.AddPoint(800, 1.0 * fat_opacity)
            
            color.AddRGBPoint(0, 0.0, 0.0, 0.0)
            color.AddRGBPoint(100, 0.1, 0.1, 0.5)
            color.AddRGBPoint(500, 0.3, 0.5, 0.8)
            color.AddRGBPoint(800, 0.9, 0.9, 1.0)
            
        elif self.current_preset == "Grayscale":
            # Grayscale with opacity scaling
            scalarOpacity.AddPoint(-1000, 0.0)
            scalarOpacity.AddPoint(0, 0.5 * fat_opacity)
            scalarOpacity.AddPoint(1000, 1.0 * bone_opacity)
            
            color.AddRGBPoint(-1000, 0.0, 0.0, 0.0)
            color.AddRGBPoint(1000, 1.0, 1.0, 1.0)
            
        elif self.current_preset == "Hot Metal":
            # Hot metal with opacity scaling
            scalarOpacity.AddPoint(-1000, 0.0)
            scalarOpacity.AddPoint(-500, 0.3 * air_opacity)
            scalarOpacity.AddPoint(0, 0.8 * fat_opacity)
            scalarOpacity.AddPoint(500, 1.0 * bone_opacity)
            
            color.AddRGBPoint(-1000, 0.0, 0.0, 0.0)
            color.AddRGBPoint(-500, 0.5, 0.0, 0.0)
            color.AddRGBPoint(0, 1.0, 0.5, 0.0)
            color.AddRGBPoint(500, 1.0, 1.0, 0.5)
        
        # Apply the transfer functions
        self.vtk_app.volumeProperty.SetScalarOpacity(scalarOpacity)
        self.vtk_app.volumeProperty.SetColor(color)
        self.vtk_app.volume.SetProperty(self.vtk_app.volumeProperty)
        
        # Store references
        self.vtk_app.scalarOpacity = scalarOpacity
        self.vtk_app.color = color
        
        self.update_renderer()

    def on_window_changed(self, value):
        """Handle window width changes (CT windowing)"""
        self.window_label.setText(f"{value} HU")
        self.apply_window_level()
        self.statusBar().showMessage(f"Window: {value} HU")

    def on_level_changed(self, value):
        """Handle level changes (CT windowing)"""
        self.level_label.setText(f"{value} HU")
        self.apply_window_level()
        self.statusBar().showMessage(f"Level: {value} HU")

    def apply_window_level(self):
        """Apply window/level to the current transfer function"""
        if self.vtk_app is None or not hasattr(self.vtk_app, 'volumeProperty'):
            return
            
        window = self.window_slider.value()
        level = self.level_slider.value()
        
        # Calculate window bounds
        window_min = level - window / 2
        window_max = level + window / 2
        
        # Get data range for context
        if hasattr(self.vtk_app, 'imageData') and self.vtk_app.imageData:
            data_min, data_max = self.vtk_app.imageData.GetScalarRange()
        else:
            data_min, data_max = -1000, 3000
        
        # Create new opacity function based on window/level
        scalarOpacity = vtk.vtkPiecewiseFunction()
        
        # Create window/level transfer function
        scalarOpacity.AddPoint(data_min, 0.0)
        scalarOpacity.AddPoint(window_min - 100, 0.0)
        scalarOpacity.AddPoint(window_min, 0.1)
        scalarOpacity.AddPoint(level, 0.8)
        scalarOpacity.AddPoint(window_max, 0.1)
        scalarOpacity.AddPoint(window_max + 100, 0.0)
        scalarOpacity.AddPoint(data_max, 0.0)
        
        # Keep the current color function or create a simple grayscale
        if hasattr(self.vtk_app, 'color') and self.vtk_app.color:
            color = self.vtk_app.color
        else:
            color = vtk.vtkColorTransferFunction()
            color.AddRGBPoint(data_min, 0.0, 0.0, 0.0)
            color.AddRGBPoint(data_max, 1.0, 1.0, 1.0)
        
        # Apply the new functions
        self.vtk_app.volumeProperty.SetScalarOpacity(scalarOpacity)
        self.vtk_app.volumeProperty.SetColor(color)
        
        # Store references
        self.vtk_app.scalarOpacity = scalarOpacity
        self.vtk_app.color = color
        
        self.update_renderer()
        
        # Update slice viewer
        if self.slice_viewer and self.slice_viewer.isVisible():
            self.slice_viewer.update_slice_view()

    def on_opacity_changed(self, value):
        """Handle overall opacity changes - SIMPLER AND MORE RELIABLE"""
        self.opacity_label.setText(f"{value}%")
        
        if self.vtk_app is not None and hasattr(self.vtk_app, 'volumeProperty'):
            # Convert to 0.0-1.0 range
            opacity = value / 100.0
            
            # SIMPLE METHOD: Always create a new transfer function based on current preset
            scalarOpacity = vtk.vtkPiecewiseFunction()
            
            # Get data range
            if hasattr(self.vtk_app, 'imageData') and self.vtk_app.imageData:
                data_min, data_max = self.vtk_app.imageData.GetScalarRange()
            else:
                data_min, data_max = -1000, 3000
            
            # Create opacity function based on current preset, scaled by overall opacity
            if hasattr(self, 'current_preset') and self.current_preset == "CT Bone":
                # Bone preset scaled by overall opacity
                scalarOpacity.AddPoint(data_min, 0.0)
                scalarOpacity.AddPoint(-200, 0.0)
                scalarOpacity.AddPoint(100, 0.1 * opacity)
                scalarOpacity.AddPoint(300, 0.8 * opacity)
                scalarOpacity.AddPoint(500, 1.0 * opacity)
            elif hasattr(self, 'current_preset') and self.current_preset == "CT Soft Tissue":
                # Soft tissue preset scaled by overall opacity
                scalarOpacity.AddPoint(data_min, 0.0)
                scalarOpacity.AddPoint(-400, 0.1 * opacity)
                scalarOpacity.AddPoint(-50, 0.8 * opacity)
                scalarOpacity.AddPoint(100, 1.0 * opacity)
                scalarOpacity.AddPoint(300, 0.3 * opacity)
            else:
                # Default: simple linear opacity
                scalarOpacity.AddPoint(data_min, 0.0)
                scalarOpacity.AddPoint(data_max, opacity)
            
            # Apply the new opacity function
            self.vtk_app.volumeProperty.SetScalarOpacity(scalarOpacity)
            self.vtk_app.scalarOpacity = scalarOpacity
            
            # Force the volume to use the updated property
            self.vtk_app.volume.SetProperty(self.vtk_app.volumeProperty)
            self.update_renderer()
            
            # Update slice viewer
            if self.slice_viewer and self.slice_viewer.isVisible():
                self.slice_viewer.update_slice_view()
        
        self.statusBar().showMessage(f"Overall opacity: {value}%")

    def on_air_opacity_changed(self, value):
        """Handle air/lung opacity changes"""
        self.air_label.setText(f"{value}%")
        if hasattr(self, 'current_preset'):
            self.apply_current_transfer_function()
        self.statusBar().showMessage(f"Air/Lung opacity: {value}%")

    def on_fat_opacity_changed(self, value):
        """Handle fat/soft tissue opacity changes"""
        self.fat_label.setText(f"{value}%")
        if hasattr(self, 'current_preset'):
            self.apply_current_transfer_function()
        self.statusBar().showMessage(f"Fat/Soft tissue opacity: {value}%")

    def on_bone_opacity_changed(self, value):
        """Handle bone opacity changes"""
        self.bone_label.setText(f"{value}%")
        if hasattr(self, 'current_preset'):
            self.apply_current_transfer_function()
        self.statusBar().showMessage(f"Bone opacity: {value}%")

    def on_brightness_changed(self, value):
        """Handle brightness changes"""
        self.brightness_label.setText(f"{value}%")
        
        # Brightness adjustment would modify the color transfer function
        # For now, just show the status message
        self.statusBar().showMessage(f"Brightness: {value}%")

    def on_contrast_changed(self, value):
        """Handle contrast changes"""
        self.contrast_label.setText(f"{value}%")
        
        # Contrast adjustment would modify the transfer function slope
        # For now, just show the status message
        self.statusBar().showMessage(f"Contrast: {value}%")

    def on_ambient_changed(self, value):
        """Handle ambient lighting changes"""
        self.ambient_label.setText(f"{value}%")
        
        if self.vtk_app is not None and hasattr(self.vtk_app, 'volumeProperty'):
            ambient = value / 100.0
            self.vtk_app.volumeProperty.SetAmbient(ambient)
            self.update_renderer()
        
        self.statusBar().showMessage(f"Ambient lighting: {value}%")

    def on_diffuse_changed(self, value):
        """Handle diffuse lighting changes"""
        self.diffuse_label.setText(f"{value}%")
        
        if self.vtk_app is not None and hasattr(self.vtk_app, 'volumeProperty'):
            diffuse = value / 100.0
            self.vtk_app.volumeProperty.SetDiffuse(diffuse)
            self.update_renderer()
        
        self.statusBar().showMessage(f"Diffuse lighting: {value}%")

    def on_specular_changed(self, value):
        """Handle specular lighting changes"""
        self.specular_label.setText(f"{value}%")
        
        if self.vtk_app is not None and hasattr(self.vtk_app, 'volumeProperty'):
            specular = value / 100.0
            self.vtk_app.volumeProperty.SetSpecular(specular)
            self.update_renderer()
        
        self.statusBar().showMessage(f"Specular lighting: {value}%")

    def on_specular_power_changed(self, value):
        """Handle specular power changes"""
        self.specular_power_label.setText(f"{value}")
        
        if self.vtk_app is not None and hasattr(self.vtk_app, 'volumeProperty'):
            self.vtk_app.volumeProperty.SetSpecularPower(value)
            self.update_renderer()
        
        self.statusBar().showMessage(f"Specular power: {value}")

    def reset_color_settings(self):
        """Reset all color settings to default"""
        # Reset sliders to default values
        self.window_slider.setValue(400)
        self.level_slider.setValue(40)
        self.opacity_slider.setValue(80)
        self.air_slider.setValue(10)
        self.fat_slider.setValue(60)
        self.bone_slider.setValue(80)
        self.brightness_slider.setValue(50)
        self.contrast_slider.setValue(50)
        
        # Reset to default transfer function
        self.tf_preset.setCurrentText("CT Bone")
        
        self.statusBar().showMessage("Color settings reset to default")

    def reset_lighting_settings(self):
        """Reset lighting settings to default"""
        self.ambient_slider.setValue(30)
        self.diffuse_slider.setValue(70)
        self.specular_slider.setValue(40)
        self.specular_power_slider.setValue(10)
        
        if self.vtk_app is not None and hasattr(self.vtk_app, 'volumeProperty'):
            self.vtk_app.volumeProperty.SetAmbient(0.3)
            self.vtk_app.volumeProperty.SetDiffuse(0.7)
            self.vtk_app.volumeProperty.SetSpecular(0.4)
            self.vtk_app.volumeProperty.SetSpecularPower(10.0)
            self.update_renderer()
        
        self.statusBar().showMessage("Lighting settings reset to default")

    def update_renderer(self):
        """Helper method to update the renderer"""
        if self.vtk_app is not None and hasattr(self.vtk_app, 'window'):
            self.vtk_app.window.Render()

    def on_measure_mode_changed(self, mode):
        if mode == "Distance":
            msg = "Distance mode selected – click 2 points in the 3D view."
        elif mode == "Angle":
            msg = "Angle mode selected – click 3 points (vertex is 2nd point)."
        elif mode == "Area":
            msg = "Area mode selected – click 3+ points, right-click to finalize."
        elif mode == "Volume":
            msg = "Volume mode selected – click 4+ points, right-click to finalize."

        self.measurement_status.setText(msg)
        self.current_measurement.setText("No active measurement")
        self.statusBar().showMessage(f"Measurement mode: {mode}")

        if hasattr(self, "start_measure_btn"):
            self.start_measure_btn.setText("Start Measurement")
            self.start_measure_btn.update()
        self.is_measuring = False


    def toggle_measurement(self):
        if not getattr(self, "is_measuring", False):
            self.start_measurement()
            self.is_measuring = True
        else:
            self.finish_measurement()
            self.is_measuring = False


    def start_measurement(self):
        """Activate interactive measurement mode (Distance, Angle, Area, Volume, etc.)"""
        if not self.vtk_app or not self.vtk_app.renderer:
            QMessageBox.warning(self, "No Model", "Please load a model or DICOM dataset first.")
            return

        mode = self.measure_mode.currentText()
        interactor = self.vtk_app.interactor

        # Create and set up the custom interactor style
        style = MeasurementInteractor(parent_viewer=self, mode=mode)
        style.SetDefaultRenderer(self.vtk_app.renderer)
        interactor.SetInteractorStyle(style)
        self.active_measurement_style = style

        if hasattr(self, "start_measure_btn"):
            self.start_measure_btn.setText("Done Measuring")
            self.start_measure_btn.update() 
            
        # Mode-specific UI instructions
        if mode == "Distance":
            text = "Click two points to measure distance."
        elif mode == "Angle":
            text = "Click three points to measure angle."
        elif mode == "Area":
            text = "Click 3+ points, then right-click or press 'Done' to finalize the polygon."
        elif mode == "Volume":
            text = "Click 4+ points, then right-click or press 'Done' to finalize the volume."
        else:
            text = f"{mode} mode active."

        # Update UI labels and state
        self.is_measuring = True
        self.statusBar().showMessage(f"Measurement mode active: {mode}")
        self.measurement_status.setText(text)
        self.current_measurement.setText("Waiting for input...")

        # Optional visual feedback (no button dependency)
        print(f"[INFO] Measurement mode started: {mode}")


    def finish_measurement(self):
        """Finalize measurement, update UI, and restore normal navigation"""
        self.is_measuring = False

        if hasattr(self, "start_measure_btn"):
            self.start_measure_btn.setText("Start Measurement")
            self.start_measure_btn.update()
            
        # Finalize measurement if applicable
        if hasattr(self, "active_measurement_style") and self.active_measurement_style:
            try:
                self.active_measurement_style.finalize_measurement()
            except Exception as e:
                print(f"[WARN] Measurement finalization error: {e}")
            self.active_measurement_style = None

        # Update UI
        self.current_measurement.setText("Measurement complete.")
        self.statusBar().showMessage("Measurement finalized.")
        self.measurement_status.setText("You may start another measurement.")

        # Restore default camera control
        if self.vtk_app and self.vtk_app.interactor:
            default_style = vtk.vtkInteractorStyleTrackballCamera()
            self.vtk_app.interactor.SetInteractorStyle(default_style)
            self.vtk_app.window.Render()

        print("[INFO] Measurement finalized and normal mode restored.")


    def cancel_measurement(self):
        if self.vtk_app and self.vtk_app.interactor:
            self.vtk_app.interactor.SetInteractorStyle(vtk.vtkInteractorStyleTrackballCamera())
            self.vtk_app.window.Render()

        self.measurement_status.setText("Measurement cancelled.")
        self.current_measurement.setText("No active measurement.")
        self.statusBar().showMessage("Measurement mode cancelled.")

        if hasattr(self, "start_measure_btn"):
            self.start_measure_btn.setText("Start Measurement")
            self.start_measure_btn.update()
        self.is_measuring = False

    def clear_measurements(self):
        """Clear measurement list and remove all measurement visuals from 3D scene."""
        # 1️⃣ Clear list & labels
        self.measurements_list.clear()
        self.current_measurement.setText("No active measurement")
        self.statusBar().showMessage("All measurements cleared.")
        self.measurement_status.setText("Measurements cleared.")

        # 2️⃣ Remove measurement visuals if interactor exists
        try:
            if hasattr(self, "active_measurement_style") and self.active_measurement_style:
                self.active_measurement_style.clear_all_measurements()
        except Exception as e:
            print(f"[WARN] Could not clear measurement visuals: {e}")

        # 3️⃣ Fallback: clear all non-model actors in the renderer (if leftover)
        try:
            if self.vtk_app and hasattr(self.vtk_app, "renderer"):
                renderer = self.vtk_app.renderer
                actors_to_remove = []
                for actor in renderer.GetActors():
                    if not hasattr(self, "model_actors") or actor not in self.model_actors:
                        actors_to_remove.append(actor)
                for actor in actors_to_remove:
                    renderer.RemoveActor(actor)
                if hasattr(self.vtk_app, "window"):
                    self.vtk_app.window.Render()
        except Exception as e:
            print(f"[WARN] Renderer cleanup fallback failed: {e}")

    def export_measurements(self):
        if self.measurements_list.count() == 0:
            QMessageBox.information(self, "No Data", "No measurements to export.")
            return

        path, _ = QFileDialog.getSaveFileName(
            self,
            "Export Measurements",
            "measurements.txt",
            "Text Files (*.txt)"
        )

        if not path:
            return

        try:
            with open(path, "w") as f:
                f.write("=== Measurement Results ===\n\n")
                for i in range(self.measurements_list.count()):
                    f.write(self.measurements_list.item(i).text() + "\n")

            QMessageBox.information(self, "Export Successful", "Measurements exported successfully.")
            self.statusBar().showMessage("Measurement data exported.")

        except Exception as e:
            QMessageBox.critical(self, "Export Error", f"Failed to export: {e}")

    def apply_translation(self):
        """Translate only the model(s), not the axis indicator."""
        self.statusBar().showMessage("Applying translation...")

        try:
            x, y, z = self.x_trans_spin.value(), self.y_trans_spin.value(), self.z_trans_spin.value()

            # Handle polygonal model(s)
            if hasattr(self, "model_actors") and self.model_actors:
                for actor in self.model_actors:
                    transform = actor.GetUserTransform() or vtk.vtkTransform()
                    transform.Translate(x, y, z)
                    actor.SetUserTransform(transform)

            # Handle volume model (DICOM volume)
            elif hasattr(self, "model_volume") and self.model_volume:
                transform = self.model_volume.GetUserTransform() or vtk.vtkTransform()
                transform.Translate(x, y, z)
                self.model_volume.SetUserTransform(transform)

            self.vtk_app.window.Render()
            self.statusBar().showMessage(f"Translated model by ({x}, {y}, {z}) mm.")
        except Exception as e:
            QMessageBox.critical(self, "Translation Error", f"Failed to apply translation: {e}")

    def apply_rotation(self):
        """Rotate only the model(s), not the axis indicator."""
        self.statusBar().showMessage("Applying rotation...")

        try:
            rx, ry, rz = self.x_rot_spin.value(), self.y_rot_spin.value(), self.z_rot_spin.value()

            if hasattr(self, "model_actors") and self.model_actors:
                for actor in self.model_actors:
                    transform = actor.GetUserTransform() or vtk.vtkTransform()
                    transform.RotateX(rx)
                    transform.RotateY(ry)
                    transform.RotateZ(rz)
                    actor.SetUserTransform(transform)

            elif hasattr(self, "model_volume") and self.model_volume:
                transform = self.model_volume.GetUserTransform() or vtk.vtkTransform()
                transform.RotateX(rx)
                transform.RotateY(ry)
                transform.RotateZ(rz)
                self.model_volume.SetUserTransform(transform)

            self.vtk_app.window.Render()
            self.statusBar().showMessage(f"Rotated model by ({rx}°, {ry}°, {rz}°).")
        except Exception as e:
            QMessageBox.critical(self, "Rotation Error", f"Failed to apply rotation: {e}")

    def apply_scaling(self):
        """Scale only the model(s), not the axis indicator."""
        self.statusBar().showMessage("Applying scaling...")

        try:
            s = self.scale_spin.value()

            if hasattr(self, "model_actors") and self.model_actors:
                for actor in self.model_actors:
                    transform = actor.GetUserTransform() or vtk.vtkTransform()
                    transform.Scale(s, s, s)
                    actor.SetUserTransform(transform)

            elif hasattr(self, "model_volume") and self.model_volume:
                transform = self.model_volume.GetUserTransform() or vtk.vtkTransform()
                transform.Scale(s, s, s)
                self.model_volume.SetUserTransform(transform)

            self.vtk_app.window.Render()
            self.statusBar().showMessage(f"Scaled model by factor {s}.")
        except Exception as e:
            QMessageBox.critical(self, "Scaling Error", f"Failed to apply scaling: {e}")

    def reset_transformations(self):
        """Reset transformations for model(s) only, keeping axes intact."""
        self.statusBar().showMessage("Resetting model transformations...")

        try:
            if hasattr(self, "model_actors") and self.model_actors:
                for actor in self.model_actors:
                    actor.SetUserTransform(None)

            if hasattr(self, "model_volume") and self.model_volume:
                self.model_volume.SetUserTransform(None)

            # Reset UI spin boxes
            self.x_trans_spin.setValue(0)
            self.y_trans_spin.setValue(0)
            self.z_trans_spin.setValue(0)
            self.x_rot_spin.setValue(0)
            self.y_rot_spin.setValue(0)
            self.z_rot_spin.setValue(0)
            self.scale_spin.setValue(1.0)

            self.vtk_app.window.Render()
            self.statusBar().showMessage("Model transformations reset.")
        except Exception as e:
            QMessageBox.critical(self, "Reset Error", f"Failed to reset transformations: {e}")

    def on_render_mode_changed(self, mode):
        """Switch between distinct rendering modes with visible differences."""
        self.statusBar().showMessage(f"Applying rendering mode: {mode}")

        try:
            renderer = self.vtk_app.renderer
            window = self.vtk_app.window
            renderer.RemoveAllViewProps()

            if hasattr(self.vtk_app, "volume") and self.vtk_app.volume:
                volume = self.vtk_app.volume
                prop = volume.GetProperty()
                mapper = self.vtk_app.volumeMapper
            else:
                volume = None
                mapper = None

            # === Volume Rendering ===
            if mode == "Volume Rendering" and volume:
                prop.ShadeOn()
                prop.SetAmbient(0.3)
                prop.SetDiffuse(0.6)
                prop.SetSpecular(0.3)

                opacity_tf = vtk.vtkPiecewiseFunction()
                opacity_tf.AddPoint(0, 0.0)
                opacity_tf.AddPoint(80, 0.1)
                opacity_tf.AddPoint(255, 0.9)
                prop.SetScalarOpacity(opacity_tf)

                color_tf = vtk.vtkColorTransferFunction()
                color_tf.AddRGBPoint(0, 0.0, 0.0, 0.0)
                color_tf.AddRGBPoint(64, 0.8, 0.5, 0.3)
                color_tf.AddRGBPoint(128, 1.0, 1.0, 0.9)
                color_tf.AddRGBPoint(255, 1.0, 1.0, 1.0)
                prop.SetColor(color_tf)

                renderer.AddVolume(volume)

            # === Surface Rendering ===
            elif mode == "Surface Rendering":
                if hasattr(self.vtk_app, "imageData"):
                    iso = vtk.vtkMarchingCubes()
                    iso.SetInputData(self.vtk_app.imageData)
                    iso.SetValue(0, 150)
                    iso.Update()

                    mapper = vtk.vtkPolyDataMapper()
                    mapper.SetInputConnection(iso.GetOutputPort())

                    actor = vtk.vtkActor()
                    actor.SetMapper(mapper)
                    actor.GetProperty().SetColor(0.9, 0.9, 0.9)
                    actor.GetProperty().SetSpecular(0.4)
                    actor.GetProperty().SetDiffuse(0.8)
                    actor.GetProperty().SetOpacity(1.0)

                    renderer.AddActor(actor)
                    self.model_actors = [actor]
                else:
                    QMessageBox.warning(self, "Surface Rendering", "No image data found for surface rendering.")

            # === Maximum Intensity Projection ===
            elif mode == "Maximum Intensity Projection" and mapper:
                mapper.SetBlendModeToMaximumIntensity()
                prop.ShadeOff()
                renderer.AddVolume(volume)

            # === Minimum Intensity Projection ===
            elif mode == "Minimum Intensity Projection" and mapper:
                mapper.SetBlendModeToMinimumIntensity()
                prop.ShadeOff()
                renderer.AddVolume(volume)

            renderer.ResetCamera()
            window.Render()
            self.statusBar().showMessage(f"Rendering mode applied: {mode}")

        except Exception as e:
            QMessageBox.critical(self, "Render Error", f"Failed to apply rendering mode: {e}")


    def on_quality_changed(self, value):
        """Adjust rendering quality visibly for all modes."""
        qualities = ["Very Low", "Low", "Medium", "High", "Very High"]
        label = qualities[value - 1]
        self.statusBar().showMessage(f"Applying {label} rendering quality...")

        try:
            mode = self.render_mode.currentText()
            renderer = self.vtk_app.renderer
            window = self.vtk_app.window

            # Volume / MIP / MinIP
            if mode in ["Volume Rendering", "Maximum Intensity Projection", "Minimum Intensity Projection"]:
                if hasattr(self.vtk_app, "volumeMapper"):
                    sample_distance = {1: 4.0, 2: 2.0, 3: 1.0, 4: 0.5, 5: 0.25}[value]
                    self.vtk_app.volumeMapper.SetSampleDistance(sample_distance)

                    if hasattr(self.vtk_app, "volume") and self.vtk_app.volume:
                        prop = self.vtk_app.volume.GetProperty()
                        prop.SetAmbient(0.1 + value * 0.1)
                        prop.SetDiffuse(0.3 + value * 0.1)
                        prop.SetSpecular(0.05 * value)

                renderer.ResetCameraClippingRange()
                window.Render()

            # Surface Rendering
            elif mode == "Surface Rendering" and hasattr(self.vtk_app, "imageData"):
                iso = vtk.vtkMarchingCubes()
                iso.SetInputData(self.vtk_app.imageData)
                iso.SetValue(0, 150)
                iso.Update()

                decimate = vtk.vtkDecimatePro()
                decimate.SetInputConnection(iso.GetOutputPort())
                reduction = {1: 0.9, 2: 0.7, 3: 0.4, 4: 0.2, 5: 0.0}[value]
                decimate.SetTargetReduction(reduction)
                decimate.PreserveTopologyOn()
                decimate.Update()

                smoother = vtk.vtkSmoothPolyDataFilter()
                smoother.SetInputConnection(decimate.GetOutputPort())
                smoother.SetNumberOfIterations(5 * value)
                smoother.Update()

                mapper = vtk.vtkPolyDataMapper()
                mapper.SetInputConnection(smoother.GetOutputPort())

                actor = vtk.vtkActor()
                actor.SetMapper(mapper)
                actor.GetProperty().SetColor(0.9, 0.9, 0.9)
                actor.GetProperty().SetSpecular(0.3 + 0.1 * value)
                actor.GetProperty().SetDiffuse(0.6 + 0.05 * value)

                renderer.RemoveAllViewProps()
                renderer.AddActor(actor)
                renderer.ResetCamera()
                window.Render()

            self.statusBar().showMessage(f"Rendering quality set to: {label}")

        except Exception as e:
            QMessageBox.warning(self, "Quality Adjustment Error", f"Could not change rendering quality: {e}")
    
    # ========== SEGMENTATION METHODS ==========
    def choose_segmentation_color(self):
        """Open color dialog for segmentation color"""
        color = QColorDialog.getColor()
        if color.isValid():
            self.seg_color_btn.setStyleSheet(f"background-color: {color.name()};")
            current_item = self.segmentation_list.currentItem()
            if current_item and hasattr(self, 'segmentations'):
                seg_name = current_item.text()
                if seg_name in self.segmentations:
                    self.segmentations[seg_name]['color'] = [color.red()/255, color.green()/255, color.blue()/255]
                    if 'actor' in self.segmentations[seg_name]:
                        self.segmentations[seg_name]['actor'].GetProperty().SetColor(
                            color.red()/255, color.green()/255, color.blue()/255
                        )
                        if self.vtk_app:
                            self.vtk_app.window.Render()

    def create_new_segmentation(self):
        """Create a new segmentation mask"""
        name, ok = QInputDialog.getText(self, "New Segmentation", "Enter segmentation name:")
        if ok and name:
            self.segmentation_list.addItem(name)
            
            if not hasattr(self, 'segmentations'):
                self.segmentations = {}
            
            self.segmentations[name] = {
                'name': name,
                'color': [0.0, 1.0, 0.0],
                'opacity': 0.7,
                'mask_data': None,
                'visible': True
            }
            
            self.segmentation_list.setCurrentRow(self.segmentation_list.count() - 1)
            self.statusBar().showMessage(f"Created new segmentation: {name}")

    def apply_segmentation(self):
        """Apply current segmentation parameters"""
        current_item = self.segmentation_list.currentItem()
        if not current_item:
            QMessageBox.warning(self, "No Selection", "Please select or create a segmentation first")
            return
        
        seg_name = current_item.text()
        
        if self.vtk_app and self.vtk_app.imageData:
            organ_preset = self.organ_preset.currentText()
            
            if organ_preset != "Custom":
                self.advanced_organ_isolation(seg_name, organ_preset)
            else:
                mode = self.seg_mode.currentText()
                if mode == "Threshold":
                    self.apply_threshold_segmentation(seg_name)
                elif mode == "Manual Brush":
                    self.seg_status.setText("Switch to slice viewer for manual segmentation")
                elif mode == "Region Growing":
                    self.apply_region_growing(seg_name)
                elif mode == "Watershed":
                    self.apply_watershed_segmentation(seg_name)
                elif mode == "AI Auto-Segment":
                    self.apply_ai_segmentation(seg_name)
            
            self.statusBar().showMessage(f"Applied segmentation to {seg_name}")
        else:
            QMessageBox.warning(self, "No Data", "Load DICOM data first")

    def advanced_organ_isolation(self, seg_name, organ_type):
        """More sophisticated organ isolation using multiple techniques"""
        if organ_type == "Liver":
            self.isolate_liver(seg_name)
        elif organ_type == "Kidneys":
            self.isolate_kidneys(seg_name)
        elif organ_type == "Brain Tissue":
            self.isolate_brain(seg_name)
        elif organ_type == "Lungs":
            self.isolate_lungs(seg_name)
        elif organ_type == "Bones":
            self.isolate_bones(seg_name)
        elif organ_type == "Heart":
            self.isolate_heart(seg_name)
        elif organ_type == "Tumor (General)":
            self.isolate_tumor_general(seg_name)
        else:
            self.apply_threshold_segmentation(seg_name)

    def isolate_liver(self, seg_name):
        """Specialized liver isolation"""
        try:
            threshold = vtk.vtkImageThreshold()
            threshold.SetInputData(self.vtk_app.imageData)
            threshold.ThresholdBetween(40, 60)
            threshold.SetInValue(1)
            threshold.SetOutValue(0)
            threshold.Update()
            
            connectivity = vtk.vtkImageConnectivityFilter()
            connectivity.SetInputConnection(threshold.GetOutputPort())
            connectivity.SetExtractionModeToLargestRegion()
            connectivity.Update()
            
            self.segmentations[seg_name]['mask_data'] = connectivity.GetOutput()
            self.create_surface_from_segmentation(seg_name)
            self.seg_status.setText("Liver isolated - largest connected region kept")
            
        except Exception as e:
            self.seg_status.setText(f"Liver isolation failed: {str(e)}")

    def isolate_kidneys(self, seg_name):
        """Kidney isolation - often need to handle both kidneys"""
        try:
            threshold = vtk.vtkImageThreshold()
            threshold.SetInputData(self.vtk_app.imageData)
            threshold.ThresholdBetween(30, 50)
            threshold.SetInValue(1)
            threshold.SetOutValue(0)
            threshold.Update()
            
            connectivity = vtk.vtkImageConnectivityFilter()
            connectivity.SetInputConnection(threshold.GetOutputPort())
            connectivity.SetExtractionModeToAllRegions()
            connectivity.Update()
            
            self.segmentations[seg_name]['mask_data'] = connectivity.GetOutput()
            self.create_surface_from_segmentation(seg_name)
            self.seg_status.setText("Kidneys isolated - both kidneys should be visible")
            
        except Exception as e:
            self.seg_status.setText(f"Kidney isolation failed: {str(e)}")

    def isolate_brain(self, seg_name):
        """Brain tissue isolation"""
        try:
            threshold = vtk.vtkImageThreshold()
            threshold.SetInputData(self.vtk_app.imageData)
            threshold.ThresholdBetween(20, 80)
            threshold.SetInValue(1)
            threshold.SetOutValue(0)
            threshold.Update()
            
            connectivity = vtk.vtkImageConnectivityFilter()
            connectivity.SetInputConnection(threshold.GetOutputPort())
            connectivity.SetExtractionModeToLargestRegion()
            connectivity.Update()
            
            self.segmentations[seg_name]['mask_data'] = connectivity.GetOutput()
            self.create_surface_from_segmentation(seg_name)
            self.seg_status.setText("Brain tissue isolated")
            
        except Exception as e:
            self.seg_status.setText(f"Brain isolation failed: {str(e)}")

    def isolate_lungs(self, seg_name):
        """Lung isolation"""
        try:
            threshold = vtk.vtkImageThreshold()
            threshold.SetInputData(self.vtk_app.imageData)
            threshold.ThresholdBetween(-1000, -400)
            threshold.SetInValue(1)
            threshold.SetOutValue(0)
            threshold.Update()
            
            connectivity = vtk.vtkImageConnectivityFilter()
            connectivity.SetInputConnection(threshold.GetOutputPort())
            connectivity.SetExtractionModeToAllRegions()
            connectivity.Update()
            
            self.segmentations[seg_name]['mask_data'] = connectivity.GetOutput()
            self.create_surface_from_segmentation(seg_name)
            self.seg_status.setText("Lungs isolated - both lungs visible")
            
        except Exception as e:
            self.seg_status.setText(f"Lung isolation failed: {str(e)}")

    def isolate_bones(self, seg_name):
        """Bone isolation"""
        try:
            threshold = vtk.vtkImageThreshold()
            threshold.SetInputData(self.vtk_app.imageData)
            threshold.ThresholdBetween(300, 2000)
            threshold.SetInValue(1)
            threshold.SetOutValue(0)
            threshold.Update()
            
            self.segmentations[seg_name]['mask_data'] = threshold.GetOutput()
            self.create_surface_from_segmentation(seg_name)
            self.seg_status.setText("Bones isolated - entire skeleton")
            
        except Exception as e:
            self.seg_status.setText(f"Bone isolation failed: {str(e)}")

    def isolate_heart(self, seg_name):
        """Heart muscle isolation"""
        try:
            threshold = vtk.vtkImageThreshold()
            threshold.SetInputData(self.vtk_app.imageData)
            threshold.ThresholdBetween(30, 50)
            threshold.SetInValue(1)
            threshold.SetOutValue(0)
            threshold.Update()
            
            connectivity = vtk.vtkImageConnectivityFilter()
            connectivity.SetInputConnection(threshold.GetOutputPort())
            connectivity.SetExtractionModeToLargestRegion()
            connectivity.Update()
            
            self.segmentations[seg_name]['mask_data'] = connectivity.GetOutput()
            self.create_surface_from_segmentation(seg_name)
            self.seg_status.setText("Heart muscle isolated")
            
        except Exception as e:
            self.seg_status.setText(f"Heart isolation failed: {str(e)}")

    def isolate_tumor_general(self, seg_name):
        """General tumor isolation"""
        try:
            threshold = vtk.vtkImageThreshold()
            threshold.SetInputData(self.vtk_app.imageData)
            threshold.ThresholdBetween(60, 120)
            threshold.SetInValue(1)
            threshold.SetOutValue(0)
            threshold.Update()
            
            connectivity = vtk.vtkImageConnectivityFilter()
            connectivity.SetInputConnection(threshold.GetOutputPort())
            connectivity.SetExtractionModeToAllRegions()
            connectivity.Update()
            
            self.segmentations[seg_name]['mask_data'] = connectivity.GetOutput()
            self.create_surface_from_segmentation(seg_name)
            self.seg_status.setText("Potential tumors isolated - review needed")
            
        except Exception as e:
            self.seg_status.setText(f"Tumor isolation failed: {str(e)}")

    def apply_threshold_segmentation(self, seg_name):
        """Apply threshold-based segmentation"""
        try:
            min_val = self.threshold_min.value()
            max_val = self.threshold_max.value()
            
            threshold = vtk.vtkImageThreshold()
            threshold.SetInputData(self.vtk_app.imageData)
            threshold.ThresholdBetween(min_val, max_val)
            threshold.SetInValue(1)
            threshold.SetOutValue(0)
            threshold.Update()
            
            self.segmentations[seg_name]['mask_data'] = threshold.GetOutput()
            self.create_surface_from_segmentation(seg_name)
            self.isolate_organ_in_main_view(seg_name, min_val, max_val)
            
        except Exception as e:
            QMessageBox.critical(self, "Segmentation Error", f"Threshold failed: {str(e)}")

    def isolate_organ_in_main_view(self, seg_name, min_val, max_val):
        """Modify main volume to highlight organ"""
        if not hasattr(self.vtk_app, 'volumeProperty'):
            return
        
        scalarOpacity = vtk.vtkPiecewiseFunction()
        color = vtk.vtkColorTransferFunction()
        
        data_min, data_max = self.vtk_app.imageData.GetScalarRange()
        transparency = 0.1
        
        scalarOpacity.AddPoint(data_min, transparency)
        scalarOpacity.AddPoint(min_val - 50, transparency)
        scalarOpacity.AddPoint(min_val, 0.8)
        scalarOpacity.AddPoint((min_val + max_val) / 2, 1.0)
        scalarOpacity.AddPoint(max_val, 0.8)
        scalarOpacity.AddPoint(max_val + 50, transparency)
        scalarOpacity.AddPoint(data_max, transparency)
        
        organ_color = self.segmentations[seg_name]['color']
        color.AddRGBPoint(data_min, 0.3, 0.3, 0.3)
        color.AddRGBPoint(min_val, organ_color[0], organ_color[1], organ_color[2])
        color.AddRGBPoint(max_val, organ_color[0], organ_color[1], organ_color[2])
        color.AddRGBPoint(data_max, 0.3, 0.3, 0.3)
        
        self.vtk_app.volumeProperty.SetScalarOpacity(scalarOpacity)
        self.vtk_app.volumeProperty.SetColor(color)
        self.vtk_app.volume.SetProperty(self.vtk_app.volumeProperty)
        self.update_renderer()

    def create_surface_from_segmentation(self, seg_name):
        """Create 3D surface from binary mask"""
        try:
            if seg_name not in self.segmentations or self.segmentations[seg_name]['mask_data'] is None:
                return
            
            marching_cubes = vtk.vtkMarchingCubes()
            marching_cubes.SetInputData(self.segmentations[seg_name]['mask_data'])
            marching_cubes.SetValue(0, 0.5)
            marching_cubes.Update()
            
            seg_data = self.segmentations[seg_name]
            
            mapper = vtk.vtkPolyDataMapper()
            mapper.SetInputConnection(marching_cubes.GetOutputPort())
            mapper.ScalarVisibilityOff()
            
            actor = vtk.vtkActor()
            actor.SetMapper(mapper)
            actor.GetProperty().SetColor(seg_data['color'])
            actor.GetProperty().SetOpacity(seg_data['opacity'])
            
            self.segmentations[seg_name]['actor'] = actor
            
            if self.vtk_app and self.vtk_app.renderer:
                self.vtk_app.renderer.AddActor(actor)
                self.vtk_app.window.Render()
                
            self.statusBar().showMessage(f"Created 3D surface for {seg_name}")
                
        except Exception as e:
            print(f"Surface creation error: {e}")
            QMessageBox.warning(self, "Surface Error", f"Failed to create 3D surface: {str(e)}")

    def apply_region_growing(self, seg_name):
        """Placeholder for region growing segmentation"""
        self.seg_status.setText("Region growing segmentation - click a seed point in 3D view")
        # Implementation would require user interaction to select seed points

    def apply_watershed_segmentation(self, seg_name):
        """Placeholder for watershed segmentation"""
        self.seg_status.setText("Watershed segmentation not yet implemented")
        # Future implementation for complex anatomical boundaries

    def apply_ai_segmentation(self, seg_name):
        """Placeholder for AI segmentation"""
        self.seg_status.setText("AI segmentation not yet implemented")
        # Future implementation using machine learning models

    def reset_segmentation(self):
        """Reset current segmentation"""
        current_item = self.segmentation_list.currentItem()
        if current_item:
            seg_name = current_item.text()
            if seg_name in self.segmentations:
                if 'actor' in self.segmentations[seg_name] and self.vtk_app:
                    self.vtk_app.renderer.RemoveActor(self.segmentations[seg_name]['actor'])
                
                self.segmentations[seg_name]['mask_data'] = None
                
                if self.vtk_app:
                    self.vtk_app.window.Render()
                
                self.statusBar().showMessage(f"Reset segmentation: {seg_name}")

    def rename_segmentation(self):
        """Rename selected segmentation"""
        current_item = self.segmentation_list.currentItem()
        if current_item:
            old_name = current_item.text()
            new_name, ok = QInputDialog.getText(self, "Rename Segmentation", "New name:", text=old_name)
            if ok and new_name and new_name != old_name:
                current_item.setText(new_name)
                if old_name in self.segmentations:
                    self.segmentations[new_name] = self.segmentations.pop(old_name)
                    self.segmentations[new_name]['name'] = new_name
                self.statusBar().showMessage(f"Renamed {old_name} to {new_name}")

    def delete_segmentation(self):
        """Delete selected segmentation"""
        current_item = self.segmentation_list.currentItem()
        if current_item:
            seg_name = current_item.text()
            reply = QMessageBox.question(self, "Delete Segmentation", 
                                    f"Delete segmentation '{seg_name}'?",
                                    QMessageBox.Yes | QMessageBox.No)
            if reply == QMessageBox.Yes:
                if seg_name in self.segmentations and 'actor' in self.segmentations[seg_name]:
                    if self.vtk_app:
                        self.vtk_app.renderer.RemoveActor(self.segmentations[seg_name]['actor'])
                        self.vtk_app.window.Render()
                
                if seg_name in self.segmentations:
                    del self.segmentations[seg_name]
                
                self.segmentation_list.takeItem(self.segmentation_list.row(current_item))
                self.statusBar().showMessage(f"Deleted segmentation: {seg_name}")

    def on_segmentation_list_changed(self):
        """Update controls when selection changes"""
        current_item = self.segmentation_list.currentItem()
        if current_item and hasattr(self, 'segmentations'):
            seg_name = current_item.text()
            if seg_name in self.segmentations:
                seg_data = self.segmentations[seg_name]
                color = seg_data['color']
                self.seg_color_btn.setStyleSheet(
                    f"background-color: rgb({int(color[0]*255)}, {int(color[1]*255)}, {int(color[2]*255)});"
                )
                self.seg_opacity.setValue(int(seg_data['opacity'] * 100))

    def on_seg_opacity_changed(self, value):
        """Handle segmentation opacity changes"""
        current_item = self.segmentation_list.currentItem()
        if current_item and hasattr(self, 'segmentations'):
            seg_name = current_item.text()
            if seg_name in self.segmentations:
                opacity = value / 100.0
                self.segmentations[seg_name]['opacity'] = opacity
                if 'actor' in self.segmentations[seg_name]:
                    self.segmentations[seg_name]['actor'].GetProperty().SetOpacity(opacity)
                    if self.vtk_app:
                        self.vtk_app.window.Render()

    def on_organ_preset_changed(self, organ_name):
        """Set threshold ranges based on selected organ"""
        if organ_name == "Custom":
            self.seg_status.setText("Set custom HU range and click Apply")
            return
        
        organ_ranges = {
            "Brain Tissue": (20, 80),
            "Liver": (40, 60),
            "Kidneys": (30, 50),
            "Lungs": (-1000, -400),
            "Bones": (300, 2000),
            "Heart": (30, 50),
            "Tumor (General)": (60, 120)
        }
        
        if organ_name in organ_ranges:
            min_val, max_val = organ_ranges[organ_name]
            self.threshold_min.setValue(min_val)
            self.threshold_max.setValue(max_val)
            self.seg_status.setText(f"Set {organ_name} range: {min_val}-{max_val} HU. Click Apply.")
            
            if self.segmentation_list.count() == 0:
                self.create_new_segmentation()
                
            current_item = self.segmentation_list.currentItem()
            if current_item:
                current_item.setText(f"{organ_name}_Segmentation")

    def on_seg_mode_changed(self, mode):
        """Update UI based on selected segmentation mode"""
        if mode == "Manual Brush":
            self.seg_status.setText("Use slice viewer for manual segmentation")
        elif mode == "Threshold":
            self.seg_status.setText("Set threshold range and click Apply")
        elif mode == "Region Growing":
            self.seg_status.setText("Click on a seed point in 3D view")
        elif mode == "Watershed":
            self.seg_status.setText("Watershed segmentation - click Apply")
        elif mode == "AI Auto-Segment":
            self.seg_status.setText("AI segmentation - click Apply")

    # ========== SETTINGS SAVE/LOAD/EXPORT METHODS ==========

    def save_settings(self):
        """Save all current visualization, transformation, and rendering settings."""
        try:
            if not self.vtk_app or not self.vtk_app.renderer:
                QMessageBox.warning(self, "No Scene", "Nothing to save — please load a model first.")
                return

            filename, _ = QFileDialog.getSaveFileName(
                self,
                "Save Visualization Settings",
                "scene_settings.json",
                "JSON Files (*.json);;All Files (*)"
            )
            if not filename:
                return
            if not filename.lower().endswith(".json"):
                filename += ".json"

            renderer = self.vtk_app.renderer
            camera = renderer.GetActiveCamera()

            settings = {
                "render_mode": getattr(self, "render_mode", None).currentText() if hasattr(self, "render_mode") else "Volume Rendering",
                "quality_level": getattr(self, "quality_slider", None).value() if hasattr(self, "quality_slider") else 3,
                "transform": {
                    "translation": {
                        "x": self.x_trans_spin.value() if hasattr(self, "x_trans_spin") else 0,
                        "y": self.y_trans_spin.value() if hasattr(self, "y_trans_spin") else 0,
                        "z": self.z_trans_spin.value() if hasattr(self, "z_trans_spin") else 0,
                    },
                    "rotation": {
                        "x": self.x_rot_spin.value() if hasattr(self, "x_rot_spin") else 0,
                        "y": self.y_rot_spin.value() if hasattr(self, "y_rot_spin") else 0,
                        "z": self.z_rot_spin.value() if hasattr(self, "z_rot_spin") else 0,
                    },
                    "scale": self.scale_spin.value() if hasattr(self, "scale_spin") else 1.0,
                },
                "camera": {
                    "position": camera.GetPosition(),
                    "focal_point": camera.GetFocalPoint(),
                    "view_up": camera.GetViewUp(),
                    "clipping_range": camera.GetClippingRange(),
                },
                "illumination": {},
            }

            # Save renderer light and color properties if present
            lights = renderer.GetLights()
            lights.InitTraversal()
            for i in range(lights.GetNumberOfItems()):
                light = lights.GetNextItem()
                settings["illumination"][f"light_{i}"] = {
                    "position": light.GetPosition(),
                    "intensity": light.GetIntensity(),
                    "color": light.GetDiffuseColor(),
                }

            with open(filename, "w") as f:
                json.dump(settings, f, indent=4)

            self.statusBar().showMessage(f"Settings saved to {filename}")
            QMessageBox.information(self, "Save Successful", f"All visualization settings saved to:\n{filename}")

        except Exception as e:
            QMessageBox.critical(self, "Save Error", f"Failed to save settings: {str(e)}")
            self.statusBar().showMessage("Error saving visualization settings")


    def load_settings(self):
        """Reload previously saved visualization and transformation settings."""
        try:
            filename, _ = QFileDialog.getOpenFileName(
                self,
                "Load Visualization Settings",
                "",
                "JSON Files (*.json);;All Files (*)"
            )
            if not filename:
                return
            with open(filename, "r") as f:
                settings = json.load(f)

            # Restore rendering mode and quality
            if hasattr(self, "render_mode") and "render_mode" in settings:
                index = self.render_mode.findText(settings["render_mode"])
                if index >= 0:
                    self.render_mode.setCurrentIndex(index)
            if hasattr(self, "quality_slider") and "quality_level" in settings:
                self.quality_slider.setValue(settings["quality_level"])

            # Restore transformations
            t = settings.get("transform", {})
            if "translation" in t:
                self.x_trans_spin.setValue(t["translation"].get("x", 0))
                self.y_trans_spin.setValue(t["translation"].get("y", 0))
                self.z_trans_spin.setValue(t["translation"].get("z", 0))
                self.apply_translation()
            if "rotation" in t:
                self.x_rot_spin.setValue(t["rotation"].get("x", 0))
                self.y_rot_spin.setValue(t["rotation"].get("y", 0))
                self.z_rot_spin.setValue(t["rotation"].get("z", 0))
                self.apply_rotation()
            if "scale" in t:
                self.scale_spin.setValue(t["scale"])
                self.apply_scaling()

            # Restore camera
            cam = settings.get("camera", {})
            if self.vtk_app and self.vtk_app.renderer:
                camera = self.vtk_app.renderer.GetActiveCamera()
                if "position" in cam:
                    camera.SetPosition(*cam["position"])
                if "focal_point" in cam:
                    camera.SetFocalPoint(*cam["focal_point"])
                if "view_up" in cam:
                    camera.SetViewUp(*cam["view_up"])
                if "clipping_range" in cam:
                    camera.SetClippingRange(*cam["clipping_range"])
                self.vtk_app.window.Render()

            self.statusBar().showMessage(f"Settings loaded from {filename}")
            QMessageBox.information(self, "Load Successful", f"Settings loaded from:\n{filename}")

        except Exception as e:
            QMessageBox.critical(self, "Load Error", f"Failed to load settings: {str(e)}")
            self.statusBar().showMessage("Error loading visualization settings")

    def export_image(self):
        """Export the current 3D view as an image (standard resolution)."""
        try:
            if self.vtk_app is None or self.vtk_app.window is None:
                QMessageBox.warning(self, "Export Error", "No 3D view available to export.")
                return

            filename, selected_filter = QFileDialog.getSaveFileName(
                self,
                "Export 3D View as Image",
                "dicom_render",
                "PNG Images (*.png);;JPEG Images (*.jpg *.jpeg);;TIFF Images (*.tiff);;All Files (*)"
            )
            if not filename:
                return

            # Determine format
            if selected_filter.startswith("PNG") or filename.lower().endswith(".png"):
                writer = vtk.vtkPNGWriter()
                if not filename.lower().endswith(".png"):
                    filename += ".png"
            elif selected_filter.startswith("JPEG") or filename.lower().endswith((".jpg", ".jpeg")):
                writer = vtk.vtkJPEGWriter()
                writer.SetQuality(95)
                if not filename.lower().endswith((".jpg", ".jpeg")):
                    filename += ".jpg"
            else:
                writer = vtk.vtkTIFFWriter()
                if not filename.lower().endswith(".tiff"):
                    filename += ".tiff"

            # Capture image from the render window
            window_to_image = vtk.vtkWindowToImageFilter()
            window_to_image.SetInput(self.vtk_app.window)
            window_to_image.SetScale(1)
            window_to_image.SetInputBufferTypeToRGB()
            window_to_image.ReadFrontBufferOff()
            window_to_image.Update()

            writer.SetFileName(filename)
            writer.SetInputConnection(window_to_image.GetOutputPort())
            writer.Write()

            self.statusBar().showMessage(f"3D view exported to {filename}")
            QMessageBox.information(self, "Export Success", f"Image exported successfully:\n{filename}")

        except Exception as e:
            QMessageBox.critical(self, "Export Error", f"Failed to export image: {e}")
            self.statusBar().showMessage("Error exporting image")

    def export_high_resolution_image(self):
        """Export high resolution image with custom resolution"""
        try:
            if self.vtk_app is None or self.vtk_app.window is None:
                QMessageBox.warning(self, "Export Error", "No 3D view available to export")
                return
                
            # Get resolution from user
            width, ok1 = QInputDialog.getInt(self, "Export High Resolution", 
                                            "Image Width:", 1920, 100, 7680, 100)
            height, ok2 = QInputDialog.getInt(self, "Export High Resolution",
                                             "Image Height:", 1080, 100, 4320, 100)
            
            if not (ok1 and ok2):
                return
                
            filename, selected_filter = QFileDialog.getSaveFileName(
                self,
                "Export High Resolution Image",
                "dicom_export_highres",
                "PNG Images (*.png);;JPEG Images (*.jpg *.jpeg);;TIFF Images (*.tiff);;All Files (*)"
            )
            
            if not filename:
                return
                
            # Determine file format
            if selected_filter.startswith("PNG") or filename.lower().endswith('.png'):
                file_format = "png"
                if not filename.lower().endswith('.png'):
                    filename += '.png'
            elif selected_filter.startswith("JPEG") or filename.lower().endswith(('.jpg', '.jpeg')):
                file_format = "jpeg"
                if not filename.lower().endswith(('.jpg', '.jpeg')):
                    filename += '.jpg'
            elif selected_filter.startswith("TIFF") or filename.lower().endswith(('.tiff', '.tif')):
                file_format = "tiff"
                if not filename.lower().endswith(('.tiff', '.tif')):
                    filename += '.tiff'
            else:
                file_format = "png"
                if not filename.lower().endswith('.png'):
                    filename += '.png'
            
            # Store original window size
            original_size = self.vtk_widget.size()
            
            try:
                # Temporarily resize the window for high-res capture
                self.vtk_widget.resize(width, height)
                QApplication.processEvents()  # Process the resize
                
                # Force render with new size
                self.vtk_app.window.SetSize(width, height)
                self.vtk_app.window.Render()
                
                # Capture image
                window_to_image = vtk.vtkWindowToImageFilter()
                window_to_image.SetInput(self.vtk_app.window)
                window_to_image.SetScale(1)
                window_to_image.SetInputBufferTypeToRGB()
                window_to_image.ReadFrontBufferOff()
                window_to_image.Update()
                
                # Write file
                if file_format == "png":
                    writer = vtk.vtkPNGWriter()
                elif file_format == "jpeg":
                    writer = vtk.vtkJPEGWriter()
                    writer.SetQuality(100)  # Maximum quality
                elif file_format == "tiff":
                    writer = vtk.vtkTIFFWriter()
                else:
                    writer = vtk.vtkPNGWriter()
                    
                writer.SetFileName(filename)
                writer.SetInputConnection(window_to_image.GetOutputPort())
                writer.Write()
                
                self.statusBar().showMessage(f"High-res image exported to {filename} ({width}x{height})")
                QMessageBox.information(self, "Export Success", 
                                      f"High resolution image exported to:\n{filename}\n\n"
                                      f"Format: {file_format.upper()}\n"
                                      f"Resolution: {width}x{height}")
                
            finally:
                # Restore original window size
                self.vtk_widget.resize(original_size)
                self.vtk_app.window.SetSize(original_size.width(), original_size.height())
                self.vtk_app.window.Render()
                
        except Exception as e:
            QMessageBox.critical(self, "Export Error", f"Failed to export high resolution image: {str(e)}")
            self.statusBar().showMessage("Error exporting high resolution image")

    # ========== SAVE/EXPORT/LOAD METHODS ==========

    def save_dicom_data(self):
        """Save the current image data as DICOM files"""
        try:
            if self.vtk_app is None or self.vtk_app.imageData is None:
                QMessageBox.warning(self, "Save Error", "No DICOM data loaded to save")
                return

            directory = QFileDialog.getExistingDirectory(
                self,
                "Select Directory to Save DICOM Files",
                "",
                QFileDialog.ShowDirsOnly
            )
            
            if not directory:
                return

            base_name, ok = QInputDialog.getText(
                self,
                "DICOM File Base Name",
                "Enter base name for DICOM files:",
                text="modified_series"
            )
            
            if not ok or not base_name:
                base_name = "modified_series"

            # Show progress
            progress = QProgressDialog("Saving DICOM files...", "Cancel", 0, 100, self)
            progress.setWindowModality(Qt.WindowModal)
            progress.show()

            # Use VTK's DICOM writer
            writer = vtk.vtkDICOMWriter()
            writer.SetDirectoryName(directory)
            writer.SetFilePrefix(base_name)
            writer.SetFilePattern("%s%04d.dcm")
            writer.SetInputData(self.vtk_app.imageData)
            writer.SetSeriesDescription(f"Modified with 3D Viewer - {QDateTime.currentDateTime().toString()}")
            
            progress.setValue(50)
            QApplication.processEvents()
            
            writer.Write()
            
            progress.setValue(100)
            
            # Estimate number of files based on dimensions
            if hasattr(self.vtk_app, 'dims'):
                num_files = self.vtk_app.dims[2]  # Number of slices in Z dimension
            else:
                num_files = "multiple"
            
            self.statusBar().showMessage(f"Saved DICOM files to {directory}")
            QMessageBox.information(self, "Save Success", 
                                f"Successfully saved DICOM files to:\n{directory}\n\n"
                                f"Base name: {base_name}\n"
                                f"Number of files: {num_files}")
            
        except Exception as e:
            QMessageBox.critical(self, "Save Error", f"Failed to save DICOM data: {str(e)}")
            self.statusBar().showMessage("Error saving DICOM data")

    def save_visualization_as_dicom(self):
        """Save the current 3D rendering as a DICOM Secondary Capture file"""
        try:
            if self.vtk_app is None or self.vtk_app.window is None:
                QMessageBox.warning(self, "Save Error", "No 3D view available to save")
                return

            filename, _ = QFileDialog.getSaveFileName(
                self,
                "Save Visualization as DICOM",
                "visualization_capture.dcm",
                "DICOM Files (*.dcm);;All Files (*)"
            )
            
            if not filename:
                return

            if not filename.lower().endswith('.dcm'):
                filename += '.dcm'

            # Capture the window as an image
            window_to_image = vtk.vtkWindowToImageFilter()
            window_to_image.SetInput(self.vtk_app.window)
            window_to_image.SetScale(1)
            window_to_image.SetInputBufferTypeToRGB()
            window_to_image.ReadFrontBufferOff()
            window_to_image.Update()

            # Convert to grayscale for DICOM
            rgb_to_gray = vtk.vtkImageLuminance()
            rgb_to_gray.SetInputConnection(window_to_image.GetOutputPort())
            rgb_to_gray.Update()

            # Create DICOM writer
            writer = vtk.vtkDICOMWriter()
            writer.SetFileName(filename)
            writer.SetInputConnection(rgb_to_gray.GetOutputPort())
            
            # Set DICOM metadata
            writer.SetPatientName("Visualization Export")
            writer.SetStudyDescription("3D Medical Visualization")
            writer.SetSeriesDescription("Secondary Capture from 3D Viewer")
            writer.SetModality("OT")  # Other modality
            
            writer.Write()
            
            self.statusBar().showMessage(f"Saved visualization as DICOM: {filename}")
            QMessageBox.information(self, "Save Success", 
                                f"Visualization saved as DICOM Secondary Capture:\n{filename}")
            
        except Exception as e:
            QMessageBox.critical(self, "Save Error", f"Failed to save visualization as DICOM: {str(e)}")
            self.statusBar().showMessage("Error saving visualization as DICOM")

    def save_model(self):
        """Save current volume data as VTK file"""
        try:
            if self.vtk_app is None or self.vtk_app.imageData is None:
                QMessageBox.warning(self, "Save Error", "No volume data to save")
                return
                
            filename, selected_filter = QFileDialog.getSaveFileName(
                self,
                "Save Volume Data",
                "volume_data",
                "VTK ImageData (*.vti);;VTK Legacy (*.vtk);;All Files (*)"
            )
            
            if not filename:
                return

            # Determine file type and set appropriate writer
            if filename.lower().endswith('.vti'):
                writer = vtk.vtkXMLImageDataWriter()
            else:
                if not filename.lower().endswith('.vtk'):
                    filename += '.vtk'
                writer = vtk.vtkImageWriter()
                
            writer.SetFileName(filename)
            writer.SetInputData(self.vtk_app.imageData)
            writer.Write()
            
            self.statusBar().showMessage(f"Saved volume data to {filename}")
            QMessageBox.information(self, "Save Success", f"Volume data saved to:\n{filename}")
            
        except Exception as e:
            QMessageBox.critical(self, "Save Error", f"Failed to save volume data: {str(e)}")
            self.statusBar().showMessage("Error saving volume data")

    def load_model(self):
        """Load saved volume data from VTK file"""
        try:
            filename, selected_filter = QFileDialog.getOpenFileName(
                self,
                "Load Volume Data",
                "",
                "VTK Files (*.vti *.vtk);;All Files (*)"
            )
            
            if not filename:
                return

            # Determine file type and set appropriate reader
            if filename.lower().endswith('.vti'):
                reader = vtk.vtkXMLImageDataReader()
            else:
                reader = vtk.vtkImageReader()
                
            reader.SetFileName(filename)
            reader.Update()
            
            loaded_data = reader.GetOutput()
            if loaded_data is None:
                QMessageBox.warning(self, "Load Error", "Failed to load volume data from file")
                return
                
            # Replace current image data with loaded data
            self.vtk_app.imageData = loaded_data
            self.vtk_app.volumeMapper.SetInputData(loaded_data)
            
            # Update dimensions and other properties
            self.vtk_app.dims = loaded_data.GetDimensions()
            self.vtk_app.spacing = loaded_data.GetSpacing()
            self.vtk_app.scalar_range = loaded_data.GetScalarRange()
            
            # Update slice information
            self.vtk_app.max_slices = {
                'axial': self.vtk_app.dims[2] - 1,
                'coronal': self.vtk_app.dims[1] - 1,  
                'sagittal': self.vtk_app.dims[0] - 1
            }
            
            self.vtk_app.slice_number = {
                'axial': self.vtk_app.dims[2] // 2,
                'coronal': self.vtk_app.dims[1] // 2,
                'sagittal': self.vtk_app.dims[0] // 2
            }
            
            # Update the renderer
            self.vtk_app.window.Render()
            
            # Update slice viewer if visible
            if self.slice_viewer and self.slice_viewer.isVisible():
                self.slice_viewer.set_slice_data(self.vtk_app)
                
            self.statusBar().showMessage(f"Loaded volume data from {filename}")
            QMessageBox.information(self, "Load Success", f"Volume data loaded from:\n{filename}")
            
        except Exception as e:
            QMessageBox.critical(self, "Load Error", f"Failed to load volume data: {str(e)}")
            self.statusBar().showMessage("Error loading volume data")

    def save_complete_scene(self):
        """Save the complete scene including DICOM data, models, and all applied settings."""
        try:
            filename, _ = QFileDialog.getSaveFileName(
                self,
                "Save Complete Scene",
                "medical_scene",
                "VTK MultiBlock (*.vtm);;All Files (*)"
            )
            if not filename:
                return
            if not filename.lower().endswith('.vtm'):
                filename += '.vtm'

            # Create multi-block dataset
            multiBlock = vtk.vtkMultiBlockDataSet()
            
            # Add volume data
            if self.vtk_app and self.vtk_app.imageData:
                multiBlock.SetBlock(0, self.vtk_app.imageData)
                multiBlock.GetMetaData(0).Set(vtk.vtkCompositeDataSet.NAME(), "VolumeData")

            # Add scene settings as a JSON string field
            settings_json = {}
            if hasattr(self, "render_mode"):
                settings_json["render_mode"] = self.render_mode.currentText()
            if hasattr(self, "quality_slider"):
                settings_json["quality_level"] = self.quality_slider.value()
            if hasattr(self, "x_trans_spin"):
                settings_json["translation"] = [
                    self.x_trans_spin.value(),
                    self.y_trans_spin.value(),
                    self.z_trans_spin.value()
                ]
            if hasattr(self, "x_rot_spin"):
                settings_json["rotation"] = [
                    self.x_rot_spin.value(),
                    self.y_rot_spin.value(),
                    self.z_rot_spin.value()
                ]
            if hasattr(self, "scale_spin"):
                settings_json["scale"] = self.scale_spin.value()

            # Store settings as field data
            str_array = vtk.vtkStringArray()
            str_array.SetName("SceneSettings")
            str_array.InsertNextValue(json.dumps(settings_json))
            multiBlock.GetFieldData().AddArray(str_array)

            # Write dataset
            writer = vtk.vtkXMLMultiBlockDataWriter()
            writer.SetFileName(filename)
            writer.SetInputData(multiBlock)
            writer.Write()

            self.statusBar().showMessage(f"Saved complete scene with settings to {filename}")
            QMessageBox.information(self, "Save Success", f"Complete scene with visualization settings saved:\n{filename}")

        except Exception as e:
            QMessageBox.critical(self, "Save Error", f"Failed to save complete scene: {str(e)}")
            self.statusBar().showMessage("Error saving complete scene")


    def load_complete_scene(self):
        """Load the complete scene including DICOM volume and visualization settings."""
        try:
            filename, _ = QFileDialog.getOpenFileName(
                self,
                "Load Complete Scene",
                "",
                "VTK MultiBlock (*.vtm);;All Files (*)"
            )
            if not filename:
                return

            reader = vtk.vtkXMLMultiBlockDataReader()
            reader.SetFileName(filename)
            reader.Update()
            multiBlock = reader.GetOutput()
            if not multiBlock:
                QMessageBox.warning(self, "Load Error", "Failed to load scene from file")
                return

            # Load image data
            volume_data = multiBlock.GetBlock(0)
            if volume_data:
                self.vtk_app.imageData = volume_data
                self.vtk_app.volumeMapper.SetInputData(volume_data)
                self.vtk_app.window.Render()

            # Restore settings from field data
            fd = multiBlock.GetFieldData()
            if fd and fd.HasArray("SceneSettings"):
                str_array = fd.GetAbstractArray("SceneSettings")
                if str_array and str_array.GetNumberOfValues() > 0:
                    settings_json = json.loads(str_array.GetValue(0))
                    # Restore transforms, mode, etc.
                    if "render_mode" in settings_json and hasattr(self, "render_mode"):
                        idx = self.render_mode.findText(settings_json["render_mode"])
                        if idx >= 0:
                            self.render_mode.setCurrentIndex(idx)
                    if "quality_level" in settings_json and hasattr(self, "quality_slider"):
                        self.quality_slider.setValue(settings_json["quality_level"])
                    if "translation" in settings_json:
                        self.x_trans_spin.setValue(settings_json["translation"][0])
                        self.y_trans_spin.setValue(settings_json["translation"][1])
                        self.z_trans_spin.setValue(settings_json["translation"][2])
                        self.apply_translation()
                    if "rotation" in settings_json:
                        self.x_rot_spin.setValue(settings_json["rotation"][0])
                        self.y_rot_spin.setValue(settings_json["rotation"][1])
                        self.z_rot_spin.setValue(settings_json["rotation"][2])
                        self.apply_rotation()
                    if "scale" in settings_json and hasattr(self, "scale_spin"):
                        self.scale_spin.setValue(settings_json["scale"])
                        self.apply_scaling()

            self.statusBar().showMessage(f"Loaded complete scene and visualization from {filename}")
            QMessageBox.information(self, "Load Success", f"Complete scene with visualization settings loaded:\n{filename}")

        except Exception as e:
            QMessageBox.critical(self, "Load Error", f"Failed to load complete scene: {str(e)}")
            self.statusBar().showMessage("Error loading complete scene")
            
    def export_comprehensive(self):
        """Comprehensive export of both data and visualization"""
        try:
            options = QMessageBox.question(
                self,
                "Comprehensive Export",
                "What would you like to export?\n\n"
                "Yes: Modified DICOM data + Visualization settings\n"
                "No: Current visualization as DICOM Secondary Capture\n"
                "Cancel: Return to main menu",
                QMessageBox.Yes | QMessageBox.No | QMessageBox.Cancel
            )
            
            if options == QMessageBox.Yes:
                self.save_dicom_data()
                self.save_settings()
                
            elif options == QMessageBox.No:
                self.save_visualization_as_dicom()
                
        except Exception as e:
            QMessageBox.critical(self, "Export Error", f"Failed to perform comprehensive export: {str(e)}")


def main():
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    window = AdvancedDICOMViewer()
    window.show()
    
    # Add F11 shortcut for fullscreen
    from PyQt5.QtWidgets import QShortcut
    from PyQt5.QtGui import QKeySequence
    fullscreen_shortcut = QShortcut(QKeySequence("F11"), window)
    fullscreen_shortcut.activated.connect(window.toggle_fullscreen)
    
    # Also add Escape to exit fullscreen
    escape_shortcut = QShortcut(QKeySequence("Escape"), window)
    escape_shortcut.activated.connect(lambda: window.showNormal() if window.isFullScreen() else None)
    
    sys.exit(app.exec_())


if __name__ == '__main__':
    main()